# Script to test and ensure all 100 product images and 6 category images return HTTP 200
$categoryImages = @{
    "Smartphones" = "https://images.unsplash.com/photo-1592750475338-74b7b21085ab?w=600&auto=format&fit=crop&q=80"
    "Laptops" = "https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=600&auto=format&fit=crop&q=80"
    "Electronics & Gadgets" = "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=600&auto=format&fit=crop&q=80"
    "Fashion & Clothing" = "https://images.unsplash.com/photo-1489987707025-afc232f7ea0f?w=600&auto=format&fit=crop&q=80"
    "Footwear" = "https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=600&auto=format&fit=crop&q=80"
    "Accessories" = "https://images.unsplash.com/photo-1524805444758-089113d48a6d?w=600&auto=format&fit=crop&q=80"
}

Write-Host "Verifying Category Images..."
foreach ($cat in $categoryImages.Keys) {
    $u = $categoryImages[$cat]
    try {
        $res = Invoke-WebRequest -Uri $u -Method Head -UseBasicParsing -TimeoutSec 5
        Write-Host "OK ($($res.StatusCode)) - $cat"
    } catch {
        Write-Host "FAILED ($($_.Exception.Message)) - $cat -> $u"
    }
}
