# Generate 100 products dataset for MySQL, PostgreSQL, and api.js
$jsonPath = 'c:\Users\msais\OneDrive\Desktop\java project\products_100.json'
$products = Get-Content $jsonPath -Raw | ConvertFrom-Json

Write-Host "Read $($products.Count) products from JSON."

# Function to escape SQL string
function Escape-Sql([string]$str) {
    if (-not $str) { return "NULL" }
    return "'" + $str.Replace("'", "''") + "'"
}

# Pricing dictionary / calculation logic
$priceMap = @{
    "P001" = @{ min = 64999; orig = 79900; img = "https://images.unsplash.com/photo-1695048133142-1a20484d2569?w=800&auto=format&fit=crop&q=80" };
    "P002" = @{ min = 74999; orig = 89900; img = "https://images.unsplash.com/photo-1695048133142-1a20484d2569?w=800&auto=format&fit=crop&q=80" };
    "P003" = @{ min = 77990; orig = 79900; img = "https://images.unsplash.com/photo-1510557880182-3d4d3cba35a5?w=800&auto=format&fit=crop&q=80" };
    "P004" = @{ min = 74999; orig = 84999; img = "https://images.unsplash.com/photo-1610945265064-0e34e5519bbf?w=800&auto=format&fit=crop&q=80" };
    "P005" = @{ min = 59999; orig = 64999; img = "https://images.unsplash.com/photo-1610945265064-0e34e5519bbf?w=800&auto=format&fit=crop&q=80" };
    "P006" = @{ min = 36999; orig = 42999; img = "https://images.unsplash.com/photo-1598327105666-5b89351aff97?w=800&auto=format&fit=crop&q=80" };
    "P007" = @{ min = 42999; orig = 45999; img = "https://images.unsplash.com/photo-1565849904461-04a58ad377e0?w=800&auto=format&fit=crop&q=80" };
    "P008" = @{ min = 32999; orig = 35999; img = "https://images.unsplash.com/photo-1565849904461-04a58ad377e0?w=800&auto=format&fit=crop&q=80" };
    "P009" = @{ min = 49999; orig = 52999; img = "https://images.unsplash.com/photo-1598327105666-5b89351aff97?w=800&auto=format&fit=crop&q=80" };
    "P010" = @{ min = 29999; orig = 33999; img = "https://images.unsplash.com/photo-1511707171634-5f897ff02560?w=800&auto=format&fit=crop&q=80" };
    "P011" = @{ min = 22999; orig = 25999; img = "https://images.unsplash.com/photo-1580910051074-3eb694886505?w=800&auto=format&fit=crop&q=80" };
    "P012" = @{ min = 30999; orig = 34999; img = "https://images.unsplash.com/photo-1580910051074-3eb694886505?w=800&auto=format&fit=crop&q=80" };
    "P013" = @{ min = 33999; orig = 37999; img = "https://images.unsplash.com/photo-1511707171634-5f897ff02560?w=800&auto=format&fit=crop&q=80" };
    "P014" = @{ min = 31999; orig = 35999; img = "https://images.unsplash.com/photo-1580910051074-3eb694886505?w=800&auto=format&fit=crop&q=80" };
    "P015" = @{ min = 23999; orig = 25999; img = "https://images.unsplash.com/photo-1598327105666-5b89351aff97?w=800&auto=format&fit=crop&q=80" };
    "P016" = @{ min = 5495; orig = 6495; img = "https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=800&auto=format&fit=crop&q=80" };
    "P017" = @{ min = 3799; orig = 5999; img = "https://images.unsplash.com/photo-1584735935682-2f2b69dff9d2?w=800&auto=format&fit=crop&q=80" };
    "P018" = @{ min = 2499; orig = 4499; img = "https://images.unsplash.com/photo-1608231387042-66d1773070a5?w=800&auto=format&fit=crop&q=80" };
    "P019" = @{ min = 4999; orig = 7999; img = "https://images.unsplash.com/photo-1551107696-a4b0c5a0d9a2?w=800&auto=format&fit=crop&q=80" };
    "P020" = @{ min = 3299; orig = 4999; img = "https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?w=800&auto=format&fit=crop&q=80" };
    "P021" = @{ min = 4199; orig = 5999; img = "https://images.unsplash.com/photo-1525966222134-fcfa99b8ae77?w=800&auto=format&fit=crop&q=80" };
    "P022" = @{ min = 1199; orig = 1899; img = "https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=800&auto=format&fit=crop&q=80" };
    "P023" = @{ min = 7499; orig = 8999; img = "https://images.unsplash.com/photo-1551107696-a4b0c5a0d9a2?w=800&auto=format&fit=crop&q=80" };
    "P024" = @{ min = 3999; orig = 4999; img = "https://images.unsplash.com/photo-1607522370275-f14206abe5d3?w=800&auto=format&fit=crop&q=80" };
    "P025" = @{ min = 2995; orig = 3495; img = "https://images.unsplash.com/photo-1603808033192-082d6919d3e1?w=800&auto=format&fit=crop&q=80" };
    "P026" = @{ min = 1499; orig = 2499; img = "https://images.unsplash.com/photo-1614252235316-8c857d38b5f4?w=800&auto=format&fit=crop&q=80" };
    "P027" = @{ min = 3695; orig = 4995; img = "https://images.unsplash.com/photo-1520639888713-7851133b1ed0?w=800&auto=format&fit=crop&q=80" };
    "P028" = @{ min = 4299; orig = 5999; img = "https://images.unsplash.com/photo-1584735935682-2f2b69dff9d2?w=800&auto=format&fit=crop&q=80" };
    "P029" = @{ min = 3295; orig = 3995; img = "https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=800&auto=format&fit=crop&q=80" };
    "P030" = @{ min = 2999; orig = 4999; img = "https://images.unsplash.com/photo-1608231387042-66d1773070a5?w=800&auto=format&fit=crop&q=80" };
    "P031" = @{ min = 4490; orig = 5990; img = "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=800&auto=format&fit=crop&q=80" };
    "P032" = @{ min = 5999; orig = 9999; img = "https://images.unsplash.com/photo-1583394838336-acd977736f90?w=800&auto=format&fit=crop&q=80" };
    "P033" = @{ min = 35900; orig = 39900; img = "https://images.unsplash.com/photo-1546435770-a3e426bf472b?w=800&auto=format&fit=crop&q=80" };
    "P034" = @{ min = 4490; orig = 5990; img = "https://images.unsplash.com/photo-1608043152269-423dbba4e7e1?w=800&auto=format&fit=crop&q=80" };
    "P035" = @{ min = 9999; orig = 13999; img = "https://images.unsplash.com/photo-1545454675-3531b543be5d?w=800&auto=format&fit=crop&q=80" };
    "P036" = @{ min = 1499; orig = 3490; img = "https://images.unsplash.com/photo-1545454675-3531b543be5d?w=800&auto=format&fit=crop&q=80" };
    "P037" = @{ min = 8995; orig = 10995; img = "https://images.unsplash.com/photo-1615663245857-ac93bb7c39e7?w=800&auto=format&fit=crop&q=80" };
    "P038" = @{ min = 2795; orig = 3495; img = "https://images.unsplash.com/photo-1587829741301-dc798b83add3?w=800&auto=format&fit=crop&q=80" };
    "P039" = @{ min = 1299; orig = 3499; img = "https://images.unsplash.com/photo-1615663245857-ac93bb7c39e7?w=800&auto=format&fit=crop&q=80" };
    "P040" = @{ min = 2999; orig = 5999; img = "https://images.unsplash.com/photo-1544197150-b99a580bb7a8?w=800&auto=format&fit=crop&q=80" };
    "P041" = @{ min = 59990; orig = 68995; img = "https://images.unsplash.com/photo-1516035069371-29a1b244cc32?w=800&auto=format&fit=crop&q=80" };
    "P042" = @{ min = 37990; orig = 45000; img = "https://images.unsplash.com/photo-1502920917128-1aa500764cbd?w=800&auto=format&fit=crop&q=80" };
    "P043" = @{ min = 1499; orig = 2199; img = "https://images.unsplash.com/photo-1583863788434-e58a36330cf0?w=800&auto=format&fit=crop&q=80" };
    "P044" = @{ min = 10499; orig = 16999; img = "https://images.unsplash.com/photo-1597872200969-2b65d56bd16b?w=800&auto=format&fit=crop&q=80" };
    "P045" = @{ min = 1099; orig = 1900; img = "https://images.unsplash.com/photo-1624823183492-3a56cf9e9c3d?w=800&auto=format&fit=crop&q=80" };
    "P046" = @{ min = 3490; orig = 3790; img = "https://images.unsplash.com/photo-1508685096489-7aacd43bd3b1?w=800&auto=format&fit=crop&q=80" };
    "P047" = @{ min = 2499; orig = 2999; img = "https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=800&auto=format&fit=crop&q=80" };
    "P048" = @{ min = 2999; orig = 4499; img = "https://images.unsplash.com/photo-1609592424109-dd9892f1b177?w=800&auto=format&fit=crop&q=80" };
    "P049" = @{ min = 999; orig = 2499; img = "https://images.unsplash.com/photo-1590658268037-6bf12165a8df?w=800&auto=format&fit=crop&q=80" };
    "P050" = @{ min = 1299; orig = 1999; img = "https://images.unsplash.com/photo-1580910051074-3eb694886505?w=800&auto=format&fit=crop&q=80" };
    "P051" = @{ min = 1695; orig = 2295; img = "https://images.unsplash.com/photo-1615663245857-ac93bb7c39e7?w=800&auto=format&fit=crop&q=80" };
    "P052" = @{ min = 499; orig = 999; img = "https://images.unsplash.com/photo-1527864550417-7fd91fc51a46?w=800&auto=format&fit=crop&q=80" };
    "P053" = @{ min = 399; orig = 799; img = "https://images.unsplash.com/photo-1583863788434-e58a36330cf0?w=800&auto=format&fit=crop&q=80" };
    "P054" = @{ min = 2299; orig = 3499; img = "https://images.unsplash.com/photo-1544197150-b99a580bb7a8?w=800&auto=format&fit=crop&q=80" };
    "P055" = @{ min = 1799; orig = 4999; img = "https://images.unsplash.com/photo-1579586337278-3befd40fd17a?w=800&auto=format&fit=crop&q=80" };
    "P056" = @{ min = 5999; orig = 7999; img = "https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=800&auto=format&fit=crop&q=80" };
    "P057" = @{ min = 2999; orig = 3999; img = "https://images.unsplash.com/photo-1579586337278-3befd40fd17a?w=800&auto=format&fit=crop&q=80" };
    "P058" = @{ min = 2695; orig = 2995; img = "https://images.unsplash.com/photo-1524805444758-089113d48a6d?w=800&auto=format&fit=crop&q=80" };
    "P059" = @{ min = 2995; orig = 5995; img = "https://images.unsplash.com/photo-1508685096489-7aacd43bd3b1?w=800&auto=format&fit=crop&q=80" };
    "P060" = @{ min = 1699; orig = 2999; img = "https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=800&auto=format&fit=crop&q=80" };
    "P061" = @{ min = 2399; orig = 3999; img = "https://images.unsplash.com/photo-1541099649105-f69ad21f3246?w=800&auto=format&fit=crop&q=80" };
    "P062" = @{ min = 799; orig = 999; img = "https://images.unsplash.com/photo-1521572267360-ee0c2909d518?w=800&auto=format&fit=crop&q=80" };
    "P063" = @{ min = 899; orig = 1799; img = "https://images.unsplash.com/photo-1602810318383-e386cc2a3ccf?w=800&auto=format&fit=crop&q=80" };
    "P064" = @{ min = 1499; orig = 2199; img = "https://images.unsplash.com/photo-1602810318383-e386cc2a3ccf?w=800&auto=format&fit=crop&q=80" };
    "P065" = @{ min = 1399; orig = 2299; img = "https://images.unsplash.com/photo-1618354691373-d851c5c3a990?w=800&auto=format&fit=crop&q=80" };
    "P066" = @{ min = 2499; orig = 4499; img = "https://images.unsplash.com/photo-1556905055-8f358a7a47b2?w=800&auto=format&fit=crop&q=80" };
    "P067" = @{ min = 2299; orig = 3999; img = "https://images.unsplash.com/photo-1552902865-b72c031ac5ea?w=800&auto=format&fit=crop&q=80" };
    "P068" = @{ min = 3295; orig = 3995; img = "https://images.unsplash.com/photo-1556905055-8f358a7a47b2?w=800&auto=format&fit=crop&q=80" };
    "P069" = @{ min = 1299; orig = 2499; img = "https://images.unsplash.com/photo-1583743814966-8936f5b7be1a?w=800&auto=format&fit=crop&q=80" };
    "P070" = @{ min = 1599; orig = 2999; img = "https://images.unsplash.com/photo-1583743814966-8936f5b7be1a?w=800&auto=format&fit=crop&q=80" };
    "P071" = @{ min = 999; orig = 1699; img = "https://images.unsplash.com/photo-1506630448388-4e683c67ddb0?w=800&auto=format&fit=crop&q=80" };
    "P072" = @{ min = 1890; orig = 2490; img = "https://images.unsplash.com/photo-1583743814966-8936f5b7be1a?w=800&auto=format&fit=crop&q=80" };
    "P073" = @{ min = 1290; orig = 1590; img = "https://images.unsplash.com/photo-1521572267360-ee0c2909d518?w=800&auto=format&fit=crop&q=80" };
    "P074" = @{ min = 2990; orig = 4590; img = "https://images.unsplash.com/photo-1541099649105-f69ad21f3246?w=800&auto=format&fit=crop&q=80" };
    "P075" = @{ min = 1699; orig = 2499; img = "https://images.unsplash.com/photo-1506630448388-4e683c67ddb0?w=800&auto=format&fit=crop&q=80" };
    "P076" = @{ min = 89990; orig = 99900; img = "https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=800&auto=format&fit=crop&q=80" };
    "P077" = @{ min = 104990; orig = 114900; img = "https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=800&auto=format&fit=crop&q=80" };
    "P078" = @{ min = 52990; orig = 64990; img = "https://images.unsplash.com/photo-1593642632823-8f785ba67e45?w=800&auto=format&fit=crop&q=80" };
    "P079" = @{ min = 58990; orig = 69990; img = "https://images.unsplash.com/photo-1496181133206-80ce9b88a853?w=800&auto=format&fit=crop&q=80" };
    "P080" = @{ min = 62990; orig = 76990; img = "https://images.unsplash.com/photo-1541807084-5c52b6b3adef?w=800&auto=format&fit=crop&q=80" };
    "P081" = @{ min = 46990; orig = 56990; img = "https://images.unsplash.com/photo-1496181133206-80ce9b88a853?w=800&auto=format&fit=crop&q=80" };
    "P082" = @{ min = 48990; orig = 59990; img = "https://images.unsplash.com/photo-1541807084-5c52b6b3adef?w=800&auto=format&fit=crop&q=80" };
    "P083" = @{ min = 54990; orig = 69990; img = "https://images.unsplash.com/photo-1588872657578-7efd1f1555ed?w=800&auto=format&fit=crop&q=80" };
    "P084" = @{ min = 69990; orig = 84990; img = "https://images.unsplash.com/photo-1588872657578-7efd1f1555ed?w=800&auto=format&fit=crop&q=80" };
    "P085" = @{ min = 64990; orig = 78990; img = "https://images.unsplash.com/photo-1588872657578-7efd1f1555ed?w=800&auto=format&fit=crop&q=80" };
    "P086" = @{ min = 72990; orig = 89990; img = "https://images.unsplash.com/photo-1588872657578-7efd1f1555ed?w=800&auto=format&fit=crop&q=80" };
    "P087" = @{ min = 74990; orig = 89990; img = "https://images.unsplash.com/photo-1588872657578-7efd1f1555ed?w=800&auto=format&fit=crop&q=80" };
    "P088" = @{ min = 139990; orig = 159990; img = "https://images.unsplash.com/photo-1593642632823-8f785ba67e45?w=800&auto=format&fit=crop&q=80" };
    "P089" = @{ min = 94990; orig = 109990; img = "https://images.unsplash.com/photo-1541807084-5c52b6b3adef?w=800&auto=format&fit=crop&q=80" };
    "P090" = @{ min = 64990; orig = 79990; img = "https://images.unsplash.com/photo-1496181133206-80ce9b88a853?w=800&auto=format&fit=crop&q=80" };
    "P091" = @{ min = 54999; orig = 69900; img = "https://images.unsplash.com/photo-1695048133142-1a20484d2569?w=800&auto=format&fit=crop&q=80" };
    "P092" = @{ min = 42999; orig = 54999; img = "https://images.unsplash.com/photo-1610945265064-0e34e5519bbf?w=800&auto=format&fit=crop&q=80" };
    "P093" = @{ min = 12999; orig = 15999; img = "https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?w=800&auto=format&fit=crop&q=80" };
    "P094" = @{ min = 12900; orig = 14900; img = "https://images.unsplash.com/photo-1600294037681-c80b4cb5b434?w=800&auto=format&fit=crop&q=80" };
    "P095" = @{ min = 6999; orig = 9999; img = "https://images.unsplash.com/photo-1590658268037-6bf12165a8df?w=800&auto=format&fit=crop&q=80" };
    "P096" = @{ min = 1299; orig = 1999; img = "https://images.unsplash.com/photo-1583863788434-e58a36330cf0?w=800&auto=format&fit=crop&q=80" };
    "P097" = @{ min = 2499; orig = 3999; img = "https://images.unsplash.com/photo-1590658268037-6bf12165a8df?w=800&auto=format&fit=crop&q=80" };
    "P098" = @{ min = 3199; orig = 4599; img = "https://images.unsplash.com/photo-1541099649105-f69ad21f3246?w=800&auto=format&fit=crop&q=80" };
    "P099" = @{ min = 1499; orig = 2299; img = "https://images.unsplash.com/photo-1521572267360-ee0c2909d518?w=800&auto=format&fit=crop&q=80" };
    "P100" = @{ min = 64990; orig = 79990; img = "https://images.unsplash.com/photo-1541807084-5c52b6b3adef?w=800&auto=format&fit=crop&q=80" };
}

# Platforms: 1: Amazon India, 2: Flipkart, 3: Myntra, 4: AJIO
$platforms = @(
    @{ id = 1; name = "Amazon India"; short = "Amazon"; logo = "https://upload.wikimedia.org/wikipedia/commons/a/a9/Amazon_logo.svg"; urlPrefix = "https://www.amazon.in/s?k=" },
    @{ id = 2; name = "Flipkart"; short = "Flipkart"; logo = "https://logos-world.net/wp-content/uploads/2020/11/Flipkart-Logo.png"; urlPrefix = "https://www.flipkart.com/search?q=" },
    @{ id = 3; name = "Myntra"; short = "Myntra"; logo = "https://images.indianexpress.com/2021/01/myntra.png"; urlPrefix = "https://www.myntra.com/" },
    @{ id = 4; name = "AJIO"; short = "AJIO"; logo = "https://assets.ajio.com/static/img/Ajio-Logo.svg"; urlPrefix = "https://www.ajio.com/search/?text=" }
)

Write-Host "Config ready. Writing generation logic..."
