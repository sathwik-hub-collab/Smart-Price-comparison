$csv = @"
No.,Product,Category,Retailer,URL
1,Apple iPhone 17,Smartphones,Amazon India,https://www.amazon.in/s?k=Apple+iPhone+17+smartphone
2,Apple iPhone 16,Smartphones,Flipkart,https://www.flipkart.com/search?q=Apple+iPhone+16+128GB
3,Samsung Galaxy S25 Ultra,Smartphones,Amazon India,https://www.amazon.in/s?k=Samsung+Galaxy+S25+Ultra
4,Samsung Galaxy S25 FE,Smartphones,Flipkart,https://www.flipkart.com/search?q=Samsung+Galaxy+S25+FE
5,OnePlus Nord 6,Smartphones,Amazon India,https://www.amazon.in/s?k=OnePlus+Nord+6+smartphone
6,iQOO 15R,Smartphones,Flipkart,https://www.flipkart.com/search?q=iQOO+15R+smartphone
7,Motorola G57 Power 5G,Smartphones,Amazon India,https://www.amazon.in/s?k=Motorola+G57+Power+5G
8,Vivo X200T,Smartphones,Flipkart,https://www.flipkart.com/search?q=Vivo+X200T+smartphone
9,POCO X8,Smartphones,Amazon India,https://www.amazon.in/s?k=POCO+X8+smartphone
10,Redmi Note 15 SE,Smartphones,Flipkart,https://www.flipkart.com/search?q=Redmi+Note+15+SE+smartphone
11,OPPO Reno16,Smartphones,Amazon India,https://www.amazon.in/s?k=OPPO+Reno16+smartphone
12,Samsung Galaxy A56 5G,Smartphones,Flipkart,https://www.flipkart.com/search?q=Samsung+Galaxy+A56+5G
13,Nothing Phone (3a),Smartphones,Amazon India,https://www.amazon.in/s?k=Nothing+Phone+3a
14,Realme P4s Lite,Smartphones,Flipkart,https://www.flipkart.com/search?q=Realme+P4s+Lite+smartphone
15,Google Pixel 9a,Smartphones,Amazon India,https://www.amazon.in/s?k=Google+Pixel+9a+smartphone
16,Apple MacBook Neo,Laptops,Flipkart,https://www.flipkart.com/search?q=Apple+MacBook+Neo+laptop
17,Apple MacBook Air 13-inch,Laptops,Amazon India,https://www.amazon.in/s?k=Apple+MacBook+Air+13+inch+M-series
18,ASUS Vivobook 15,Laptops,Flipkart,https://www.flipkart.com/search?q=ASUS+Vivobook+15+laptop
19,Lenovo IdeaPad Slim 3,Laptops,Amazon India,https://www.amazon.in/s?k=Lenovo+IdeaPad+Slim+3+laptop
20,HP 15s,Laptops,Flipkart,https://www.flipkart.com/search?q=HP+15s+laptop
21,Acer Aspire Lite,Laptops,Amazon India,https://www.amazon.in/s?k=Acer+Aspire+Lite+laptop
22,Dell Inspiron 15,Laptops,Flipkart,https://www.flipkart.com/search?q=Dell+Inspiron+15+laptop
23,Samsung Galaxy Book4,Laptops,Amazon India,https://www.amazon.in/s?k=Samsung+Galaxy+Book4+laptop
24,Lenovo LOQ Gaming Laptop,Laptops,Flipkart,https://www.flipkart.com/search?q=Lenovo+LOQ+gaming+laptop
25,ASUS TUF Gaming A15,Laptops,Amazon India,https://www.amazon.in/s?k=ASUS+TUF+Gaming+A15+laptop
26,Realme Buds T310,Electronics & Gadgets,Flipkart,https://www.flipkart.com/search?q=Realme+Buds+T310+earbuds
27,OnePlus Nord Buds,Electronics & Gadgets,Amazon India,https://www.amazon.in/s?k=OnePlus+Nord+Buds+earbuds
28,Samsung 25W USB-C Adapter,Electronics & Gadgets,Flipkart,https://www.flipkart.com/search?q=Samsung+25W+USB+C+travel+adapter
29,Portronics Conch Theta C,Electronics & Gadgets,Amazon India,https://www.amazon.in/s?k=Portronics+Conch+Theta+C+Type+C+earphones
30,Apple EarPods USB-C,Electronics & Gadgets,Flipkart,https://www.flipkart.com/search?q=Apple+EarPods+USB-C
31,Apple AirPods 4,Electronics & Gadgets,Amazon India,https://www.amazon.in/s?k=Apple+AirPods+4
32,Apple AirPods Pro (2nd gen),Electronics & Gadgets,Flipkart,https://www.flipkart.com/search?q=Apple+AirPods+Pro+2nd+generation
33,JBL Tune 770NC,Electronics & Gadgets,Amazon India,https://www.amazon.in/s?k=JBL+Tune+770NC+headphones
34,boAt Stone Bluetooth Speaker,Electronics & Gadgets,Flipkart,https://www.flipkart.com/search?q=boAt+Stone+Bluetooth+speaker
35,Sony WH-CH720N,Electronics & Gadgets,Amazon India,https://www.amazon.in/s?k=Sony+WH-CH720N+headphones
36,Noise ColorFit Pro 6 Max,Electronics & Gadgets,Flipkart,https://www.flipkart.com/search?q=Noise+ColorFit+Pro+6+Max+smartwatch
37,NoiseFit Halo 3,Electronics & Gadgets,Amazon India,https://www.amazon.in/s?k=NoiseFit+Halo+3+smartwatch
38,GOBOULT Trail Smartwatch,Electronics & Gadgets,Flipkart,https://www.flipkart.com/search?q=GOBOULT+Trail+smartwatch
39,Fastrack Revoltt X2,Electronics & Gadgets,Amazon India,https://www.amazon.in/s?k=Fastrack+Revoltt+X2+smartwatch
40,Garmin Forerunner,Electronics & Gadgets,Flipkart,https://www.flipkart.com/search?q=Garmin+Forerunner+smartwatch
41,Samsung Galaxy Buds3 Pro,Electronics & Gadgets,Amazon India,https://www.amazon.in/s?k=Samsung+Galaxy+Buds3+Pro
42,Anker PowerCore power bank,Electronics & Gadgets,Flipkart,https://www.flipkart.com/search?q=Anker+PowerCore+power+bank
43,Ambrane braided Type-C cable,Electronics & Gadgets,Amazon India,https://www.amazon.in/s?k=Ambrane+Unbreakable+braided+Type+C+cable
44,Logitech MX Master mouse,Electronics & Gadgets,Flipkart,https://www.flipkart.com/search?q=Logitech+MX+Master+wireless+mouse
45,Canon EOS R50,Electronics & Gadgets,Amazon India,https://www.amazon.in/s?k=Canon+EOS+R50+mirrorless+camera
46,Men's oversized graphic T-shirt,Fashion & Clothing,Myntra,https://www.myntra.com/men-oversized-graphic-t-shirt
47,Men's slim-fit jeans,Fashion & Clothing,AJIO,https://www.ajio.com/search/?text=men+slim+fit+jeans
48,Men's casual cotton shirt,Fashion & Clothing,Flipkart,https://www.flipkart.com/search?q=men+casual+cotton+shirt
49,Women's straight-fit jeans,Fashion & Clothing,Myntra,https://www.myntra.com/women-straight-fit-jeans
50,Women's kurta set,Fashion & Clothing,AJIO,https://www.ajio.com/search/?text=women+kurta+set
51,Women's Anarkali suit,Fashion & Clothing,Flipkart,https://www.flipkart.com/search?q=women+Anarkali+suit
52,Women's co-ord set,Fashion & Clothing,Myntra,https://www.myntra.com/women-co-ord-set
53,Men's hoodie,Fashion & Clothing,AJIO,https://www.ajio.com/search/?text=men+hoodie+sweatshirt
54,Women's puffer jacket,Fashion & Clothing,Flipkart,https://www.flipkart.com/search?q=women+puffer+jacket
55,Men's bomber jacket,Fashion & Clothing,Myntra,https://www.myntra.com/men-bomber-jacket
56,Women's floral dress,Fashion & Clothing,AJIO,https://www.ajio.com/search/?text=women+floral+midi+dress
57,Men's polo T-shirt,Fashion & Clothing,Flipkart,https://www.flipkart.com/search?q=men+polo+t+shirt
58,Women's wide-leg trousers,Fashion & Clothing,Myntra,https://www.myntra.com/women-wide-leg-trousers
59,Men's joggers,Fashion & Clothing,AJIO,https://www.ajio.com/search/?text=men+joggers
60,Women's ethnic dupatta,Fashion & Clothing,Flipkart,https://www.flipkart.com/search?q=women+ethnic+dupatta
61,Women's cardigan,Fashion & Clothing,Myntra,https://www.myntra.com/women-cardigan-sweater
62,Men's linen shirt,Fashion & Clothing,AJIO,https://www.ajio.com/search/?text=men+linen+shirt
63,Women's blazer,Fashion & Clothing,Flipkart,https://www.flipkart.com/search?q=women+blazer
64,Men's tracksuit,Fashion & Clothing,Myntra,https://www.myntra.com/men-tracksuit
65,Women's everyday leggings,Fashion & Clothing,AJIO,https://www.ajio.com/search/?text=women+everyday+leggings
66,Campus HALL women's sneakers,Footwear,AJIO,https://www.ajio.com/search/?text=Campus+HALL+women+sneakers
67,Red Tape women's sneakers,Footwear,Amazon India,https://www.amazon.in/s?k=Red+Tape+women+sneakers
68,Power women's running shoes,Footwear,Flipkart,https://www.flipkart.com/search?q=Power+women+running+shoes
69,Centrino men's casual sneakers,Footwear,Myntra,https://www.myntra.com/centrino-men-casual-sneakers
70,Nike Air Max,Footwear,AJIO,https://www.ajio.com/search/?text=Nike+Air+Max+shoes
71,Adidas Runfalcon,Footwear,Amazon India,https://www.amazon.in/s?k=Adidas+Runfalcon+shoes
72,Puma Smashic sneakers,Footwear,Flipkart,https://www.flipkart.com/search?q=Puma+Smashic+sneakers
73,Skechers Go Walk,Footwear,Myntra,https://www.myntra.com/skechers-go-walk-shoes
74,Crocs Classic Clog,Footwear,AJIO,https://www.ajio.com/search/?text=Crocs+Classic+Clog
75,Bata men's formal shoes,Footwear,Amazon India,https://www.amazon.in/s?k=Bata+men+formal+shoes
76,Liberty men's sandals,Footwear,Flipkart,https://www.flipkart.com/search?q=Liberty+men+sandals
77,Women's block-heel sandals,Footwear,Myntra,https://www.myntra.com/women-block-heel-sandals
78,Men's sports sandals,Footwear,AJIO,https://www.ajio.com/search/?text=men+sports+sandals
79,Women's ballet flats,Footwear,Amazon India,https://www.amazon.in/s?k=women+ballet+flats
80,Men's running shoes,Footwear,Flipkart,https://www.flipkart.com/search?q=men+running+shoes
81,Safari Pixibeat 36L backpack,Accessories,Amazon India,https://www.amazon.in/s?k=Safari+Pixibeat+36L+laptop+backpack
82,Fur Jaden anti-theft backpack,Accessories,Flipkart,https://www.flipkart.com/search?q=Fur+Jaden+anti+theft+laptop+backpack
83,Gear Classic anti-theft backpack,Accessories,Myntra,https://www.myntra.com/gear-classic-anti-theft-backpack
84,Wesley Spartan travel backpack,Accessories,AJIO,https://www.ajio.com/search/?text=Wesley+Spartan+travel+laptop+backpack
85,uppercase laptop sleeve,Accessories,Amazon India,https://www.amazon.in/s?k=uppercase+laptop+sleeve
86,Lavie Sport Triumph backpack,Accessories,Flipkart,https://www.flipkart.com/search?q=Lavie+Sport+Triumph+laptop+backpack
87,Safari Saga 32L backpack,Accessories,Myntra,https://www.myntra.com/safari-saga-32l-laptop-backpack
88,Women's crossbody sling bag,Accessories,AJIO,https://www.ajio.com/search/?text=women+crossbody+sling+bag
89,Men's RFID wallet,Accessories,Amazon India,https://www.amazon.in/s?k=men+RFID+wallet
90,Women's tote handbag,Accessories,Flipkart,https://www.flipkart.com/search?q=women+tote+handbag
91,Minimalist stainless-steel watch,Accessories,Myntra,https://www.myntra.com/minimalist-stainless-steel-wrist-watch
92,Women's fashion earrings,Accessories,AJIO,https://www.ajio.com/search/?text=women+fashion+earrings
93,Unisex UV-protection sunglasses,Accessories,Amazon India,https://www.amazon.in/s?k=unisex+UV+protection+sunglasses
94,Leather-look belt,Accessories,Flipkart,https://www.flipkart.com/search?q=men+leather+look+belt
95,Everyday baseball cap,Accessories,Myntra,https://www.myntra.com/unisex-baseball-cap
96,Travel organiser pouch set,Accessories,AJIO,https://www.ajio.com/search/?text=travel+organiser+pouch+set
97,Phone case for iPhone 16,Accessories,Amazon India,https://www.amazon.in/s?k=iPhone+16+phone+case
98,Tempered glass screen protector,Accessories,Flipkart,https://www.flipkart.com/search?q=smartphone+tempered+glass+screen+protector
99,Laptop stand adjustable,Accessories,Myntra,https://www.myntra.com/adjustable-laptop-stand
100,Compact USB-C hub,Accessories,AJIO,https://www.ajio.com/search/?text=USB+C+hub+multiport
"@

$rows = $csv | ConvertFrom-Csv
$jsItems = @()

foreach ($r in $rows) {
    $no = [int]$r.'No.'
    $name = $r.Product.Replace("'", "\'")
    $cat = $r.Category.Replace("'", "\'")
    $ret = $r.Retailer.Replace("'", "\'")
    $url = $r.URL.Replace("'", "\'")
    
    $jsItems += "  { no: $no, name: '$name', category: '$cat', retailer: '$ret', url: '$url' }"
}

$jsCode = "const VERIFIED_CATALOG_LINKS = [`n" + ($jsItems -join ",`n") + "`n];"
[System.IO.File]::WriteAllText("$PSScriptRoot\..\frontend\js\catalog-links-data.js", $jsCode, [System.Text.Encoding]::UTF8)
Write-Host "Generated catalog-links-data.js with $($rows.Count) items"

