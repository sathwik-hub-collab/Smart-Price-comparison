$urls = @(
  'https://images.unsplash.com/photo-1592750475338-74b7b21085ab?w=600',
  'https://images.unsplash.com/photo-1510557880182-3d4d3cba35a5?w=600',
  'https://images.unsplash.com/photo-1546868871-7041f2a55e12?w=600',
  'https://images.unsplash.com/photo-1608248597359-bb59c086d4e1?w=500',
  'https://images.unsplash.com/photo-1542272604-780c96856592?w=500',
  'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=500'
)

foreach ($u in $urls) {
  try {
    $res = Invoke-WebRequest -Uri $u -Method Head -UseBasicParsing -TimeoutSec 5
    Write-Host "OK ($($res.StatusCode)): $u"
  } catch {
    Write-Host "FAILED ($($_.Exception.Message)): $u"
  }
}
