$res = Invoke-WebRequest -Uri 'http://localhost:8080/index.html' -UseBasicParsing
Write-Host "Index.html status: $($res.StatusCode)"
Write-Host "Length: $($res.Content.Length)"
$hasDir = $res.Content.Contains('verifiedProductsDirectory')
Write-Host "Contains verifiedProductsDirectory: $hasDir"

$jsRes = Invoke-WebRequest -Uri 'http://localhost:8080/js/catalog-links-data.js' -UseBasicParsing
Write-Host "catalog-links-data.js status: $($jsRes.StatusCode)"
Write-Host "Length: $($jsRes.Content.Length)"
$urlCompRes = Invoke-WebRequest -Uri 'http://localhost:8080/js/url-comparison.js' -UseBasicParsing
Write-Host "url-comparison.js status: $($urlCompRes.StatusCode)"
Write-Host "Length: $($urlCompRes.Content.Length)"
$hasDirLogic = $urlCompRes.Content.Contains('initVerifiedProductsDirectory')
Write-Host "Contains initVerifiedProductsDirectory: $hasDirLogic"
