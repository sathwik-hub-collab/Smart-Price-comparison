$items = Get-Content 'PriceHunt/frontend/js/products_100.json' -Raw | ConvertFrom-Json
foreach ($g in ($items | Group-Object category)) {
    Write-Host "=== CATEGORY: $($g.Name) ($($g.Count) products) ==="
    foreach ($p in $g.Group) {
        Write-Host "  [$($p.id)] $($p.name) | $($p.originStore) | $($p.directStoreUrl)"
    }
}
