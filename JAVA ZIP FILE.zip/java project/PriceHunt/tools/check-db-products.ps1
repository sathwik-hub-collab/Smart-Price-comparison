$products = Invoke-RestMethod -Uri 'http://localhost:8080/api/products'
Write-Host "Total products in DB: $($products.Count)"
$p16 = $products | Where-Object { $_.name -match 'iPhone 16' } | Select-Object -First 1
if ($p16) {
    Write-Host "Found $($p16.name) with ID $($p16.id)"
    $hist = Invoke-RestMethod -Uri "http://localhost:8080/api/track/history-30d/$($p16.id)"
    Write-Host "Snapshots for $($p16.name): $($hist.snapshots.Count)"
    Write-Host "Sellers: $(($hist.snapshots | Select-Object -ExpandProperty sellerName -Unique) -join ', ')"
    Write-Host "Explanation: $($hist.explanation)"
}

