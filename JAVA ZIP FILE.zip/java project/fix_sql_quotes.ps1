$files = @(
    "PriceHunt/database/seed_100_products.sql",
    "PriceHunt/database/seed_postgres_100.sql",
    "PriceHunt/database/sample-data.sql"
)

foreach ($f in $files) {
    if (Test-Path $f) {
        $c = [System.IO.File]::ReadAllText($f, [System.Text.Encoding]::UTF8)
        # Fix any unescaped single quotes inside the URL parameter
        $c = $c -replace "'https://www\.amazon\.in/s\?k=Levi's", "'https://www.amazon.in/s?k=Levi''s"
        $c = $c -replace "'https://www\.flipkart\.com/search\?q=Levi's", "'https://www.flipkart.com/search?q=Levi''s"
        $c = $c -replace "'https://www\.myntra\.com/Levi's", "'https://www.myntra.com/Levi''s"
        $c = $c -replace "'https://www\.ajio\.com/search/\?text=Levi's", "'https://www.ajio.com/search/?text=Levi''s"
        [System.IO.File]::WriteAllText($f, $c, [System.Text.Encoding]::UTF8)
        Write-Host "Sanitized $f"
    }
}
