# Generates MySQL / PostgreSQL seed files directly from the verified 100-product JSON catalogue
param()

$jsonPath = 'c:\Users\msais\OneDrive\Desktop\java project\PriceHunt\frontend\js\products_100.json'
$products = Get-Content $jsonPath -Raw | ConvertFrom-Json

Write-Host "Generating SQL seeds from $($products.Count) verified products..."

# 1. Build MySQL seed (PriceHunt/database/sample-data.sql and seed_100_products.sql)
$sqlSb = [System.Text.StringBuilder]::new()
[void]$sqlSb.AppendLine("-- ============================================================================")
[void]$sqlSb.AppendLine("-- PRICEHUNT 100-PRODUCT DATABASE SEED")
[void]$sqlSb.AppendLine("-- Source: 100 Trending E-commerce Product Research Catalogue (India)")
[void]$sqlSb.AppendLine("-- Platforms: Amazon, Flipkart, Myntra, AJIO")
[void]$sqlSb.AppendLine("-- ============================================================================")
[void]$sqlSb.AppendLine("")
[void]$sqlSb.AppendLine("SET FOREIGN_KEY_CHECKS = 0;")
[void]$sqlSb.AppendLine("TRUNCATE TABLE price_alerts;")
[void]$sqlSb.AppendLine("TRUNCATE TABLE favorites;")
[void]$sqlSb.AppendLine("TRUNCATE TABLE price_history;")
[void]$sqlSb.AppendLine("TRUNCATE TABLE product_listings;")
[void]$sqlSb.AppendLine("TRUNCATE TABLE products;")
[void]$sqlSb.AppendLine("TRUNCATE TABLE platforms;")
[void]$sqlSb.AppendLine("SET FOREIGN_KEY_CHECKS = 1;")
[void]$sqlSb.AppendLine("")
[void]$sqlSb.AppendLine("INSERT INTO platforms (id, name, website_url, logo_url, is_active) VALUES")
[void]$sqlSb.AppendLine("(1, 'Amazon', 'https://www.amazon.in', 'https://upload.wikimedia.org/wikipedia/commons/a/a9/Amazon_logo.svg', 1),")
[void]$sqlSb.AppendLine("(2, 'Flipkart', 'https://www.flipkart.com', 'https://logos-world.net/wp-content/uploads/2020/11/Flipkart-Logo.png', 1),")
[void]$sqlSb.AppendLine("(3, 'Myntra', 'https://www.myntra.com', 'https://images.indianexpress.com/2021/01/myntra.png', 1),")
[void]$sqlSb.AppendLine("(4, 'Ajio', 'https://www.ajio.com', 'https://assets.ajio.com/static/img/Ajio-Logo.svg', 1);")
[void]$sqlSb.AppendLine("")

# Products INSERT
[void]$sqlSb.AppendLine("INSERT INTO products (id, name, brand, model, category, description, image_url) VALUES")
$pInserts = @()
foreach ($p in $products) {
    $prodId = $p.id
    $escName = $p.name.Replace("'", "''")
    $escBrand = $p.brand.Replace("'", "''")
    $escModel = $p.model.Replace("'", "''")
    $escCat = $p.category.Replace("'", "''")
    $escDesc = $p.description.Replace("'", "''")
    $escImg = $p.imageUrl.Replace("'", "''")
    $pInserts += "($prodId, '$escName', '$escBrand', '$escModel', '$escCat', '$escDesc', '$escImg')"
}
[void]$sqlSb.AppendLine(($pInserts -join ",`n") + ";")
[void]$sqlSb.AppendLine("")

# Listings INSERT
[void]$sqlSb.AppendLine("INSERT INTO product_listings (id, product_id, platform_id, product_url, price, original_price, discount_percentage, rating, review_count, in_stock, seller_name, is_best_deal) VALUES")
$lInserts = @()
$histInserts = @()
$listingCounter = 1

foreach ($p in $products) {
    $prodId = $p.id
    foreach ($l in $p.listings) {
        $lId = $listingCounter++
        $platId = $l.platformId
        $escUrl = $l.productUrl.Replace("'", "''")
        $price = $l.price
        $orig = $l.originalPrice
        $disc = $l.discountPercentage
        $rat = $l.rating
        $rev = $l.reviewCount
        $inStock = if ($l.inStock) { 1 } else { 0 }
        $escSeller = $l.sellerName.Replace("'", "''")
        $isBest = if ($l.isBestDeal) { 1 } else { 0 }
        $lInserts += "($lId, $prodId, $platId, '$escUrl', $price, $orig, $disc, $rat, $rev, $inStock, '$escSeller', $isBest)"

        # Price history record
        $histInserts += "($prodId, $platId, $price, NOW())"
    }
}
[void]$sqlSb.AppendLine(($lInserts -join ",`n") + ";")
[void]$sqlSb.AppendLine("")

# Price History INSERT
[void]$sqlSb.AppendLine("INSERT INTO price_history (product_id, platform_id, price, recorded_at) VALUES")
[void]$sqlSb.AppendLine(($histInserts -join ",`n") + ";")

$sqlContent = $sqlSb.ToString()

Set-Content -Path 'c:\Users\msais\OneDrive\Desktop\java project\PriceHunt\database\sample-data.sql' -Value $sqlContent -Encoding UTF8
Set-Content -Path 'c:\Users\msais\OneDrive\Desktop\java project\seed_100_products.sql' -Value $sqlContent -Encoding UTF8
Write-Host "MySQL seed files generated successfully."

# 2. Build PostgreSQL seed
$pgSb = [System.Text.StringBuilder]::new()
[void]$pgSb.AppendLine("-- PostgreSQL Seed Script for PriceHunt (100 Verified Research Catalogue Products)")
[void]$pgSb.AppendLine("TRUNCATE TABLE price_alerts, favorites, price_history, product_listings, products, platforms CASCADE;")
[void]$pgSb.AppendLine("")
[void]$pgSb.AppendLine("INSERT INTO platforms (id, name, website_url, logo_url, is_active) VALUES")
[void]$pgSb.AppendLine("(1, 'Amazon', 'https://www.amazon.in', 'https://upload.wikimedia.org/wikipedia/commons/a/a9/Amazon_logo.svg', true),")
[void]$pgSb.AppendLine("(2, 'Flipkart', 'https://www.flipkart.com', 'https://logos-world.net/wp-content/uploads/2020/11/Flipkart-Logo.png', true),")
[void]$pgSb.AppendLine("(3, 'Myntra', 'https://www.myntra.com', 'https://images.indianexpress.com/2021/01/myntra.png', true),")
[void]$pgSb.AppendLine("(4, 'Ajio', 'https://www.ajio.com', 'https://assets.ajio.com/static/img/Ajio-Logo.svg', true);")
[void]$pgSb.AppendLine("")
[void]$pgSb.AppendLine("INSERT INTO products (id, name, brand, model, category, description, image_url) VALUES")
[void]$pgSb.AppendLine(($pInserts -join ",`n") + ";")
[void]$pgSb.AppendLine("")

$pgListings = $lInserts | ForEach-Object {
    $_ -replace ", 1, '", ", true, '" -replace ", 0, '", ", false, '" -replace ", 1\)", ", true)" -replace ", 0\)", ", false)"
}
[void]$pgSb.AppendLine("INSERT INTO product_listings (id, product_id, platform_id, product_url, price, original_price, discount_percentage, rating, review_count, in_stock, seller_name, is_best_deal) VALUES")
[void]$pgSb.AppendLine(($pgListings -join ",`n") + ";")
[void]$pgSb.AppendLine("")
[void]$pgSb.AppendLine("INSERT INTO price_history (product_id, platform_id, price, recorded_at) VALUES")
[void]$pgSb.AppendLine(($histInserts -join ",`n") + ";")

Set-Content -Path 'c:\Users\msais\OneDrive\Desktop\java project\seed_postgres_100.sql' -Value ($pgSb.ToString()) -Encoding UTF8
Write-Host "PostgreSQL seed generated successfully."
