# ==============================================================================
# Complete Generator for 100 Products Research Catalogue
# India - Amazon, Flipkart, Myntra, AJIO
# Fully Synchronized with PDF Catalogue (Smartphones, Laptops, Electronics & Gadgets, Fashion & Clothing, Footwear, Accessories)
# ==============================================================================

$products = @(
    # --- Smartphones (15 products: 1-15) ---
    @{ id=1; name="Apple iPhone 17"; cat="Smartphones"; brand="Apple"; retailer="Amazon India"; url="https://www.amazon.in/s?k=Apple+iPhone+17+smartphone"; min=89999; orig=99900; img="https://images.unsplash.com/photo-1592750475338-74b7b21085ab?w=700&auto=format&fit=crop&q=80"; desc="Next-gen flagship with A19 Pro silicon, titanium frame, and revolutionary ultra-thin display bezel." },
    @{ id=2; name="Apple iPhone 16"; cat="Smartphones"; brand="Apple"; retailer="Flipkart"; url="https://www.flipkart.com/search?q=Apple+iPhone+16+128GB"; min=74999; orig=79900; img="https://images.unsplash.com/photo-1510557880182-3d4d3cba35a5?w=700&auto=format&fit=crop&q=80"; desc="Apple Intelligence powered smartphone with Camera Control button, 48MP Fusion camera, and A18 chip." },
    @{ id=3; name="Samsung Galaxy S25 Ultra"; cat="Smartphones"; brand="Samsung"; retailer="Amazon India"; url="https://www.amazon.in/s?k=Samsung+Galaxy+S25+Ultra"; min=124999; orig=139999; img="https://images.unsplash.com/photo-1610945265064-0e34e5519bbf?w=700&auto=format&fit=crop&q=80"; desc="Ultimate Galaxy AI flagship with built-in S-Pen, Snapdragon 8 Elite, 200MP camera, and titanium frame." },
    @{ id=4; name="Samsung Galaxy S25 FE"; cat="Smartphones"; brand="Samsung"; retailer="Flipkart"; url="https://www.flipkart.com/search?q=Samsung+Galaxy+S25+FE"; min=54999; orig=64999; img="https://images.unsplash.com/photo-1598327105666-5b89351aff97?w=700&auto=format&fit=crop&q=80"; desc="Fan Edition premium flagship offering Galaxy AI features, Dynamic AMOLED 2X 120Hz display, and pro camera." },
    @{ id=5; name="OnePlus Nord 6"; cat="Smartphones"; brand="OnePlus"; retailer="Amazon India"; url="https://www.amazon.in/s?k=OnePlus+Nord+6+smartphone"; min=31999; orig=37999; img="https://images.unsplash.com/photo-1565849904461-04a58ad377e0?w=700&auto=format&fit=crop&q=80"; desc="Mid-range powerhouse featuring 100W SUPERVOOC charging, Sony LYT sensor, and OxygenOS fluidity." },
    @{ id=6; name="iQOO 15R"; cat="Smartphones"; brand="iQOO"; retailer="Flipkart"; url="https://www.flipkart.com/search?q=iQOO+15R+smartphone"; min=38999; orig=44999; img="https://images.unsplash.com/photo-1580910051074-3eb694886505?w=700&auto=format&fit=crop&q=80"; desc="High-performance gaming phone with flagship Snapdragon processor, supercomputing chip, and 6000mAh battery." },
    @{ id=7; name="Motorola G57 Power 5G"; cat="Smartphones"; brand="Motorola"; retailer="Amazon India"; url="https://www.amazon.in/s?k=Motorola+G57+Power+5G"; min=14999; orig=18999; img="https://images.unsplash.com/photo-1546868871-7041f2a55e12?w=700&auto=format&fit=crop&q=80"; desc="Massive 6000mAh battery champion with vegan leather finish, clean Android experience, and 5G speeds." },
    @{ id=8; name="Vivo X200T"; cat="Smartphones"; brand="Vivo"; retailer="Flipkart"; url="https://www.flipkart.com/search?q=Vivo+X200T+smartphone"; min=52999; orig=59999; img="https://images.unsplash.com/photo-1565849904461-04a58ad377e0?w=700&auto=format&fit=crop&q=80"; desc="ZEISS co-engineered optics smartphone featuring telephoto portrait capability and Dimensity 9400 power." },
    @{ id=9; name="POCO X8"; cat="Smartphones"; brand="POCO"; retailer="Amazon India"; url="https://www.amazon.in/s?k=POCO+X8+smartphone"; min=18499; orig=22999; img="https://images.unsplash.com/photo-1574944985070-8f3ebc6b79d2?w=700&auto=format&fit=crop&q=80"; desc="Speed-demon phone with 1.5K AMOLED 120Hz display, dual stereo speakers, and turbo fast charging." },
    @{ id=10; name="Redmi Note 15 SE"; cat="Smartphones"; brand="Redmi"; retailer="Flipkart"; url="https://www.flipkart.com/search?q=Redmi+Note+15+SE+smartphone"; min=15999; orig=19999; img="https://images.unsplash.com/photo-1585060544812-6b45742d762f?w=700&auto=format&fit=crop&q=80"; desc="India's beloved Note series offering 108MP clarity, Corning Gorilla Glass protection, and 5G reliability." },
    @{ id=11; name="OPPO Reno16"; cat="Smartphones"; brand="OPPO"; retailer="Amazon India"; url="https://www.amazon.in/s?k=OPPO+Reno16+smartphone"; min=37999; orig=42999; img="https://images.unsplash.com/photo-1567581935884-3349723552ca?w=700&auto=format&fit=crop&q=80"; desc="AI portrait expert smartphone with ultra-slim aesthetic, velvet glass back, and ColorOS intelligence." },
    @{ id=12; name="Samsung Galaxy A56 5G"; cat="Smartphones"; brand="Samsung"; retailer="Flipkart"; url="https://www.flipkart.com/search?q=Samsung+Galaxy+A56+5G"; min=33999; orig=39999; img="https://images.unsplash.com/photo-1598327105666-5b89351aff97?w=700&auto=format&fit=crop&q=80"; desc="Premium A-series phone with IP67 water resistance, 4 OS upgrades, Knox Vault security, and OIS camera." },
    @{ id=13; name="Nothing Phone (3a)"; cat="Smartphones"; brand="Nothing"; retailer="Amazon India"; url="https://www.amazon.in/s?k=Nothing+Phone+3a"; min=23999; orig=27999; img="https://images.unsplash.com/photo-1512499617640-c74ae3a79d37?w=700&auto=format&fit=crop&q=80"; desc="Iconic transparent design with customizable Glyph Interface LEDs, custom Dimensity 7200 Pro, and Nothing OS." },
    @{ id=14; name="Realme P4s Lite"; cat="Smartphones"; brand="Realme"; retailer="Flipkart"; url="https://www.flipkart.com/search?q=Realme+P4s+Lite+smartphone"; min=11999; orig=14999; img="https://images.unsplash.com/photo-1580910051074-3eb694886505?w=700&auto=format&fit=crop&q=80"; desc="Value-packed 5G device with smooth 90Hz eye-comfort display, AI clear face photography, and long battery life." },
    @{ id=15; name="Google Pixel 9a"; cat="Smartphones"; brand="Google"; retailer="Amazon India"; url="https://www.amazon.in/s?k=Google+Pixel+9a+smartphone"; min=42999; orig=49999; img="https://images.unsplash.com/photo-1598327105666-5b89351aff97?w=700&auto=format&fit=crop&q=80"; desc="Pure Google Android experience with Tensor G4 chip, Magic Eraser, Best Take, and 7 years of feature drops." },

    # --- Laptops (10 products: 16-25) ---
    @{ id=16; name="Apple MacBook Neo"; cat="Laptops"; brand="Apple"; retailer="Flipkart"; url="https://www.flipkart.com/search?q=Apple+MacBook+Neo+laptop"; min=114990; orig=129900; img="https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=700&auto=format&fit=crop&q=80"; desc="Next-gen Apple silicon notebook delivering unbelievable speed, Liquid Retina XDR screen, and silent fanless design." },
    @{ id=17; name="Apple MacBook Air 13-inch"; cat="Laptops"; brand="Apple"; retailer="Amazon India"; url="https://www.amazon.in/s?k=Apple+MacBook+Air+13+inch+M-series"; min=82990; orig=99900; img="https://images.unsplash.com/photo-1611186871348-b1ce696e52c9?w=700&auto=format&fit=crop&q=80"; desc="Ultra-thin aluminum laptop with Apple M-series chip, up to 18 hours battery life, and MagSafe 3 charging." },
    @{ id=18; name="ASUS Vivobook 15"; cat="Laptops"; brand="ASUS"; retailer="Flipkart"; url="https://www.flipkart.com/search?q=ASUS+Vivobook+15+laptop"; min=37990; orig=49990; img="https://images.unsplash.com/photo-1496181133206-80ce9b88a853?w=700&auto=format&fit=crop&q=80"; desc="Sleek daily productivity laptop with 15.6-inch FHD anti-glare display, 180-degree lay-flat hinge, and fast SSD." },
    @{ id=19; name="Lenovo IdeaPad Slim 3"; cat="Laptops"; brand="Lenovo"; retailer="Amazon India"; url="https://www.amazon.in/s?k=Lenovo+IdeaPad+Slim+3+laptop"; min=34990; orig=47990; img="https://images.unsplash.com/photo-1588872657578-7efd1f1555ed?w=700&auto=format&fit=crop&q=80"; desc="Military-grade tested slim notebook with Dolby Audio, webcam privacy shutter, and Rapid Charge boost." },
    @{ id=20; name="HP 15s"; cat="Laptops"; brand="HP"; retailer="Flipkart"; url="https://www.flipkart.com/search?q=HP+15s+laptop"; min=41990; orig=52990; img="https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?w=700&auto=format&fit=crop&q=80"; desc="Dependable Windows 11 laptop with Intel Core processor, micro-edge bezel display, and full numeric keypad." },
    @{ id=21; name="Acer Aspire Lite"; cat="Laptops"; brand="Acer"; retailer="Amazon India"; url="https://www.amazon.in/s?k=Acer+Aspire+Lite+laptop"; min=31990; orig=42990; img="https://images.unsplash.com/photo-1525547719571-a2d4ac8945e2?w=700&auto=format&fit=crop&q=80"; desc="Lightweight metal cover laptop engineered for students and professionals seeking dependable performance." },
    @{ id=22; name="Dell Inspiron 15"; cat="Laptops"; brand="Dell"; retailer="Flipkart"; url="https://www.flipkart.com/search?q=Dell+Inspiron+15+laptop"; min=44990; orig=56990; img="https://images.unsplash.com/photo-1593642632823-8f785ba67e45?w=700&auto=format&fit=crop&q=80"; desc="Ergonomic lift-hinge design with carbon black chassis, expansive keyboard, and Dell ComfortView screen." },
    @{ id=23; name="Samsung Galaxy Book4"; cat="Laptops"; brand="Samsung"; retailer="Amazon India"; url="https://www.amazon.in/s?k=Samsung+Galaxy+Book4+laptop"; min=63990; orig=78990; img="https://images.unsplash.com/photo-1531297484001-80022131f5a1?w=700&auto=format&fit=crop&q=80"; desc="Seamless Galaxy ecosystem integration, ultra-slim aluminum profile, and intelligent multi-control functionality." },
    @{ id=24; name="Lenovo LOQ Gaming Laptop"; cat="Laptops"; brand="Lenovo"; retailer="Flipkart"; url="https://www.flipkart.com/search?q=Lenovo+LOQ+gaming+laptop"; min=71990; orig=89990; img="https://images.unsplash.com/photo-1603302576837-37561b2e2302?w=700&auto=format&fit=crop&q=80"; desc="Dedicated gaming rig featuring NVIDIA GeForce RTX graphics, high-refresh 144Hz screen, and Lenovo AI Engine+." },
    @{ id=25; name="ASUS TUF Gaming A15"; cat="Laptops"; brand="ASUS"; retailer="Amazon India"; url="https://www.amazon.in/s?k=ASUS+TUF+Gaming+A15+laptop"; min=67990; orig=84990; img="https://images.unsplash.com/photo-1587202372775-e229f172b9d7?w=700&auto=format&fit=crop&q=80"; desc="Rugged MIL-STD-810H certified gaming notebook with self-cleaning dual fans and immersive Dolby Atmos audio." },

    # --- Electronics & Gadgets (20 products: 26-45) ---
    @{ id=26; name="Realme Buds T310"; cat="Electronics & Gadgets"; brand="Realme"; retailer="Flipkart"; url="https://www.flipkart.com/search?q=Realme+Buds+T310+earbuds"; min=2199; orig=3999; img="https://images.unsplash.com/photo-1590658268037-6bf12165a8df?w=700&auto=format&fit=crop&q=80"; desc="46dB Hybrid Active Noise Cancellation TWS earbuds with 360-degree spatial audio and 40 hours total playtime." },
    @{ id=27; name="OnePlus Nord Buds"; cat="Electronics & Gadgets"; brand="OnePlus"; retailer="Amazon India"; url="https://www.amazon.in/s?k=OnePlus+Nord+Buds+earbuds"; min=2299; orig=2999; img="https://images.unsplash.com/photo-1572536147248-ac59a8abfa4b?w=700&auto=format&fit=crop&q=80"; desc="12.4mm titanium dynamic drivers delivering deep bass, IP55 sweat resistance, and ultra-fast Flash Charge." },
    @{ id=28; name="Samsung 25W USB-C Adapter"; cat="Electronics & Gadgets"; brand="Samsung"; retailer="Flipkart"; url="https://www.flipkart.com/search?q=Samsung+25W+USB+C+travel+adapter"; min=1299; orig=1999; img="https://images.unsplash.com/photo-1583863788434-e58a36330cf0?w=700&auto=format&fit=crop&q=80"; desc="Official Samsung Super Fast Charging adapter with Power Delivery 3.0 PPS protocol for Galaxy devices." },
    @{ id=29; name="Portronics Conch Theta C"; cat="Electronics & Gadgets"; brand="Portronics"; retailer="Amazon India"; url="https://www.amazon.in/s?k=Portronics+Conch+Theta+C+Type+C+earphones"; min=399; orig=899; img="https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=700&auto=format&fit=crop&q=80"; desc="Direct Type-C in-ear earphones with built-in high-definition microphone, DAC chip, and tangle-free cord." },
    @{ id=30; name="Apple EarPods USB-C"; cat="Electronics & Gadgets"; brand="Apple"; retailer="Flipkart"; url="https://www.flipkart.com/search?q=Apple+EarPods+USB-C"; min=1899; orig=2000; img="https://images.unsplash.com/photo-1600294037681-c80b4cb5b434?w=700&auto=format&fit=crop&q=80"; desc="Authentic Apple wired EarPods engineered to maximize acoustic output with inline remote for music and calls." },
    @{ id=31; name="Apple AirPods 4"; cat="Electronics & Gadgets"; brand="Apple"; retailer="Amazon India"; url="https://www.amazon.in/s?k=Apple+AirPods+4"; min=12900; orig=14900; img="https://images.unsplash.com/photo-1600294037681-c80b4cb5b434?w=700&auto=format&fit=crop&q=80"; desc="Redesigned AirPods 4 powered by Apple H2 chip, personalized spatial audio with dynamic head tracking, and USB-C case." },
    @{ id=32; name="Apple AirPods Pro (2nd gen)"; cat="Electronics & Gadgets"; brand="Apple"; retailer="Flipkart"; url="https://www.flipkart.com/search?q=Apple+AirPods+Pro+2nd+generation"; min=21990; orig=24900; img="https://images.unsplash.com/photo-1588423771073-b8903fbb85b5?w=700&auto=format&fit=crop&q=80"; desc="Industry-leading Pro active noise cancellation, adaptive transparency, touch volume swipe, and MagSafe case with speaker." },
    @{ id=33; name="JBL Tune 770NC"; cat="Electronics & Gadgets"; brand="JBL"; retailer="Amazon India"; url="https://www.amazon.in/s?k=JBL+Tune+770NC+headphones"; min=5999; orig=9999; img="https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=700&auto=format&fit=crop&q=80"; desc="Adaptive Noise Cancelling wireless over-ear headphones with JBL Pure Bass sound and up to 70 hours battery life." },
    @{ id=34; name="boAt Stone Bluetooth Speaker"; cat="Electronics & Gadgets"; brand="boAt"; retailer="Flipkart"; url="https://www.flipkart.com/search?q=boAt+Stone+Bluetooth+speaker"; min=1799; orig=3990; img="https://images.unsplash.com/photo-1545454675-3531b543be5d?w=700&auto=format&fit=crop&q=80"; desc="Rugged outdoor portable Bluetooth speaker with IPX7 water protection, powerful bass radiator, and TWS pairing." },
    @{ id=35; name="Sony WH-CH720N"; cat="Electronics & Gadgets"; brand="Sony"; retailer="Amazon India"; url="https://www.amazon.in/s?k=Sony+WH-CH720N+headphones"; min=8490; orig=14990; img="https://images.unsplash.com/photo-1546435770-a3e426bf472b?w=700&auto=format&fit=crop&q=80"; desc="Lightweight wireless noise cancelling headphones featuring Sony Integrated Processor V1 and multipoint Bluetooth connection." },
    @{ id=36; name="Noise ColorFit Pro 6 Max"; cat="Electronics & Gadgets"; brand="Noise"; retailer="Flipkart"; url="https://www.flipkart.com/search?q=Noise+ColorFit+Pro+6+Max+smartwatch"; min=2499; orig=5999; img="https://images.unsplash.com/photo-1508685096489-7aacd43bd3b1?w=700&auto=format&fit=crop&q=80"; desc="Large AMOLED screen smartwatch with Tru Sync Bluetooth calling, functional rotating crown, and 150+ sports modes." },
    @{ id=37; name="NoiseFit Halo 3"; cat="Electronics & Gadgets"; brand="Noise"; retailer="Amazon India"; url="https://www.amazon.in/s?k=NoiseFit+Halo+3+smartwatch"; min=2999; orig=7999; img="https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=700&auto=format&fit=crop&q=80"; desc="Circular round dial premium smartwatch with metallic bezel, always-on display, health tracker, and AI voice assistance." },
    @{ id=38; name="GOBOULT Trail Smartwatch"; cat="Electronics & Gadgets"; brand="Boult"; retailer="Flipkart"; url="https://www.flipkart.com/search?q=GOBOULT+Trail+smartwatch"; min=1799; orig=4999; img="https://images.unsplash.com/photo-1508685096489-7aacd43bd3b1?w=700&auto=format&fit=crop&q=80"; desc="Adventure ready rugged smartwatch with zinc alloy frame, continuous SpO2 monitor, and IP68 waterproof rating." },
    @{ id=39; name="Fastrack Revoltt X2"; cat="Electronics & Gadgets"; brand="Fastrack"; retailer="Amazon India"; url="https://www.amazon.in/s?k=Fastrack+Revoltt+X2+smartwatch"; min=1995; orig=4995; img="https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=700&auto=format&fit=crop&q=80"; desc="Youth-centric smartwatch with high brightness display, single-chip BT calling, animated watch faces, and fast charging." },
    @{ id=40; name="Garmin Forerunner"; cat="Electronics & Gadgets"; brand="Garmin"; retailer="Flipkart"; url="https://www.flipkart.com/search?q=Garmin+Forerunner+smartwatch"; min=24990; orig=32990; img="https://images.unsplash.com/photo-1508685096489-7aacd43bd3b1?w=700&auto=format&fit=crop&q=80"; desc="Pro athlete GPS running watch with wrist-based heart rate, training status metrics, and Garmin Coach adaptive plans." },
    @{ id=41; name="Samsung Galaxy Buds3 Pro"; cat="Electronics & Gadgets"; brand="Samsung"; retailer="Amazon India"; url="https://www.amazon.in/s?k=Samsung+Galaxy+Buds3+Pro"; min=16999; orig=19999; img="https://images.unsplash.com/photo-1590658268037-6bf12165a8df?w=700&auto=format&fit=crop&q=80"; desc="Blade design earbuds with Blade Lights, 24-bit Hi-Fi audio, adaptive noise control, and real-time Galaxy AI Interpreter." },
    @{ id=42; name="Anker PowerCore power bank"; cat="Electronics & Gadgets"; brand="Anker"; retailer="Flipkart"; url="https://www.flipkart.com/search?q=Anker+PowerCore+power+bank"; min=2499; orig=3999; img="https://images.unsplash.com/photo-1583863788434-e58a36330cf0?w=700&auto=format&fit=crop&q=80"; desc="Compact 10000mAh portable charger with PowerIQ high-speed voltage boost technology and MultiProtect safety." },
    @{ id=43; name="Ambrane braided Type-C cable"; cat="Electronics & Gadgets"; brand="Ambrane"; retailer="Amazon India"; url="https://www.amazon.in/s?k=Ambrane+Unbreakable+braided+Type+C+cable"; min=249; orig=599; img="https://images.unsplash.com/photo-1583863788434-e58a36330cf0?w=700&auto=format&fit=crop&q=80"; desc="Ultra-durable nylon braided 100W fast charging cable with 480Mbps data sync speed and reinforced joints." },
    @{ id=44; name="Logitech MX Master mouse"; cat="Electronics & Gadgets"; brand="Logitech"; retailer="Flipkart"; url="https://www.flipkart.com/search?q=Logitech+MX+Master+wireless+mouse"; min=7995; orig=10995; img="https://images.unsplash.com/photo-1615663245857-ac93bb7c39e7?w=700&auto=format&fit=crop&q=80"; desc="Ergonomic master wireless mouse with MagSpeed electromagnetic scroll wheel, 8K DPI glass sensor, and quiet clicks." },
    @{ id=45; name="Canon EOS R50"; cat="Electronics & Gadgets"; brand="Canon"; retailer="Amazon India"; url="https://www.amazon.in/s?k=Canon+EOS+R50+mirrorless+camera"; min=58990; orig=69990; img="https://images.unsplash.com/photo-1516035069371-29a1b244cc32?w=700&auto=format&fit=crop&q=80"; desc="Lightweight RF-mount mirrorless camera with 24.2MP APS-C sensor, Dual Pixel CMOS AF II, and uncropped 4K video." },

    # --- Fashion & Clothing (20 products: 46-65) ---
    @{ id=46; name="Men's oversized graphic T-shirt"; cat="Fashion & Clothing"; brand="Urban Monkey"; retailer="Myntra"; url="https://www.myntra.com/men-oversized-graphic-t-shirt"; min=799; orig=1599; img="https://images.unsplash.com/photo-1521572267360-ee0c2909d518?w=700&auto=format&fit=crop&q=80"; desc="240 GSM heavy combed cotton streetwear tee with dropped shoulders, ribbed neck, and puff printed back art." },
    @{ id=47; name="Men's slim-fit jeans"; cat="Fashion & Clothing"; brand="Spykar"; retailer="AJIO"; url="https://www.ajio.com/search/?text=men+slim+fit+jeans"; min=1499; orig=2999; img="https://images.unsplash.com/photo-1541099649105-f69ad21f3246?w=700&auto=format&fit=crop&q=80"; desc="Comfort-stretch dark wash denim jeans with 5-pocket styling, contrast stitching, and durable brass zipper." },
    @{ id=48; name="Men's casual cotton shirt"; cat="Fashion & Clothing"; brand="Highlander"; retailer="Flipkart"; url="https://www.flipkart.com/search?q=men+casual+cotton+shirt"; min=699; orig=1499; img="https://images.unsplash.com/photo-1602810318383-e386cc2a3ccf?w=700&auto=format&fit=crop&q=80"; desc="Breathable pure cotton casual long sleeve shirt with spread collar, curved hemline, and chest patch pocket." },
    @{ id=49; name="Women's straight-fit jeans"; cat="Fashion & Clothing"; brand="Kotty"; retailer="Myntra"; url="https://www.myntra.com/women-straight-fit-jeans"; min=999; orig=2499; img="https://images.unsplash.com/photo-1541099649105-f69ad21f3246?w=700&auto=format&fit=crop&q=80"; desc="High-waist classic straight leg denim jeans with clean finished waistband and vintage light wash aesthetics." },
    @{ id=50; name="Women's kurta set"; cat="Fashion & Clothing"; brand="BIBA"; retailer="AJIO"; url="https://www.ajio.com/search/?text=women+kurta+set"; min=1899; orig=3999; img="https://images.unsplash.com/photo-1610030469983-98e550d6193c?w=700&auto=format&fit=crop&q=80"; desc="Ethnic printed straight cotton kurta paired with tapered palazzos and matching organza printed dupatta." },
    @{ id=51; name="Women's Anarkali suit"; cat="Fashion & Clothing"; brand="Libas"; retailer="Flipkart"; url="https://www.flipkart.com/search?q=women+Anarkali+suit"; min=1599; orig=3499; img="https://images.unsplash.com/photo-1610030469983-98e550d6193c?w=700&auto=format&fit=crop&q=80"; desc="Flared festive Anarkali suit set with intricate embroidery on yoke, churidar bottoms, and sheer border dupatta." },
    @{ id=52; name="Women's co-ord set"; cat="Fashion & Clothing"; brand="Street 9"; retailer="Myntra"; url="https://www.myntra.com/women-co-ord-set"; min=1299; orig=2799; img="https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?w=700&auto=format&fit=crop&q=80"; desc="Contemporary 2-piece monochrome co-ord set featuring relaxed button shirt and high-waisted wide trousers." },
    @{ id=53; name="Men's hoodie"; cat="Fashion & Clothing"; brand="Roadster"; retailer="AJIO"; url="https://www.ajio.com/search/?text=men+hoodie+sweatshirt"; min=899; orig=1999; img="https://images.unsplash.com/photo-1556905055-8f358a7a47b2?w=700&auto=format&fit=crop&q=80"; desc="Soft fleece-lined pullover hooded sweatshirt with kangaroo pocket, drawstring hood, and ribbed cuffs." },
    @{ id=54; name="Women's puffer jacket"; cat="Fashion & Clothing"; brand="Fort Collins"; retailer="Flipkart"; url="https://www.flipkart.com/search?q=women+puffer+jacket"; min=1499; orig=3299; img="https://images.unsplash.com/photo-1544923246-77307dd654cb?w=700&auto=format&fit=crop&q=80"; desc="Lightweight quilted winter jacket with windproof outer shell, mock collar, and zip-through front closure." },
    @{ id=55; name="Men's bomber jacket"; cat="Fashion & Clothing"; brand="Mast & Harbour"; retailer="Myntra"; url="https://www.myntra.com/men-bomber-jacket"; min=1399; orig=3199; img="https://images.unsplash.com/photo-1548883354-7622d03aca27?w=700&auto=format&fit=crop&q=80"; desc="Classic varsity-style bomber jacket featuring baseball collar, snap button front, and contrast striped cuffs." },
    @{ id=56; name="Women's floral dress"; cat="Fashion & Clothing"; brand="Tokyo Talkies"; retailer="AJIO"; url="https://www.ajio.com/search/?text=women+floral+midi+dress"; min=749; orig=1699; img="https://images.unsplash.com/photo-1572804013309-59a88b7e92f1?w=700&auto=format&fit=crop&q=80"; desc="Flowy summer floral print A-line midi dress with V-neckline, flutter short sleeves, and tie-up waist belt." },
    @{ id=57; name="Men's polo T-shirt"; cat="Fashion & Clothing"; brand="U.S. Polo Assn."; retailer="Flipkart"; url="https://www.flipkart.com/search?q=men+polo+t+shirt"; min=999; orig=1999; img="https://images.unsplash.com/photo-1618354691373-d851c5c3a990?w=700&auto=format&fit=crop&q=80"; desc="Signature pique cotton polo shirt featuring 2-button placket, ribbed collar, and embroidered chest horse logo." },
    @{ id=58; name="Women's wide-leg trousers"; cat="Fashion & Clothing"; brand="Marks & Spencer"; retailer="Myntra"; url="https://www.myntra.com/women-wide-leg-trousers"; min=1199; orig=2499; img="https://images.unsplash.com/photo-1594633312681-425c7b97ccd1?w=700&auto=format&fit=crop&q=80"; desc="Tailored high-rise formal pleated wide-leg trousers with front slant pockets and zip fly with hook bar." },
    @{ id=59; name="Men's joggers"; cat="Fashion & Clothing"; brand="HRX"; retailer="AJIO"; url="https://www.ajio.com/search/?text=men+joggers"; min=799; orig=1799; img="https://images.unsplash.com/photo-1552902865-b72c031ac5ea?w=700&auto=format&fit=crop&q=80"; desc="Activewear stretch French terry joggers with elasticated waistband, external drawcord, and zip secure pockets." },
    @{ id=60; name="Women's ethnic dupatta"; cat="Fashion & Clothing"; brand="W"; retailer="Flipkart"; url="https://www.flipkart.com/search?q=women+ethnic+dupatta"; min=499; orig=1199; img="https://images.unsplash.com/photo-1610030469983-98e550d6193c?w=700&auto=format&fit=crop&q=80"; desc="Traditional Chanderi silk dupatta adorned with gold zari borders, tassel embellishments, and ethnic motifs." },
    @{ id=61; name="Women's cardigan"; cat="Fashion & Clothing"; brand="Forever 21"; retailer="Myntra"; url="https://www.myntra.com/women-cardigan-sweater"; min=1099; orig=2299; img="https://images.unsplash.com/photo-1434389677669-e08b4cac3105?w=700&auto=format&fit=crop&q=80"; desc="Cozy ribbed knit button-down cardigan sweater with V-neck, tortoise shell buttons, and drop shoulder fit." },
    @{ id=62; name="Men's linen shirt"; cat="Fashion & Clothing"; brand="Linen Club"; retailer="AJIO"; url="https://www.ajio.com/search/?text=men+linen+shirt"; min=1699; orig=3299; img="https://images.unsplash.com/photo-1602810318383-e386cc2a3ccf?w=700&auto=format&fit=crop&q=80"; desc="100% pure European flax linen long sleeve shirt with mandarin collar, soft wash finish, and natural cooling." },
    @{ id=63; name="Women's blazer"; cat="Fashion & Clothing"; brand="MANGO"; retailer="Flipkart"; url="https://www.flipkart.com/search?q=women+blazer"; min=2499; orig=4999; img="https://images.unsplash.com/photo-1584273143981-41c073dfe8f8?w=700&auto=format&fit=crop&q=80"; desc="Structured single-breasted blazer jacket with notched lapels, padded shoulders, and flap side pockets." },
    @{ id=64; name="Men's tracksuit"; cat="Fashion & Clothing"; brand="Puma"; retailer="Myntra"; url="https://www.myntra.com/men-tracksuit"; min=2799; orig=5499; img="https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?w=700&auto=format&fit=crop&q=80"; desc="Performance dryCELL tracksuit consisting of full-zip track jacket and matching tapered track pants with Puma cat logo." },
    @{ id=65; name="Women's everyday leggings"; cat="Fashion & Clothing"; brand="Lyra"; retailer="AJIO"; url="https://www.ajio.com/search/?text=women+everyday+leggings"; min=399; orig=699; img="https://images.unsplash.com/photo-1506629082955-511b1aa562c8?w=700&auto=format&fit=crop&q=80"; desc="Premium 4-way stretch combed cotton ankle-length leggings with ultra-soft waistband and anti-pilling fabric." },

    # --- Footwear (15 products: 66-80) ---
    @{ id=66; name="Campus HALL women's sneakers"; cat="Footwear"; brand="Campus"; retailer="AJIO"; url="https://www.ajio.com/search/?text=Campus+HALL+women+sneakers"; min=1199; orig=1899; img="https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?w=700&auto=format&fit=crop&q=80"; desc="Sporty lifestyle sneaker with breathable mesh upper, Yoga Max insole cushioning, and slip-resistant phylon outsole." },
    @{ id=67; name="Red Tape women's sneakers"; cat="Footwear"; brand="Red Tape"; retailer="Amazon India"; url="https://www.amazon.in/s?k=Red+Tape+women+sneakers"; min=1499; orig=4999; img="https://images.unsplash.com/photo-1560769629-975ec94e6a86?w=700&auto=format&fit=crop&q=80"; desc="Clean white low-top casual sneakers crafted with premium PU upper, padded collar, and TPR sole grip." },
    @{ id=68; name="Power women's running shoes"; cat="Footwear"; brand="Power"; retailer="Flipkart"; url="https://www.flipkart.com/search?q=Power+women+running+shoes"; min=1299; orig=2499; img="https://images.unsplash.com/photo-1584735935682-2f2b69dff9d2?w=700&auto=format&fit=crop&q=80"; desc="Ultra-light running shoes engineered with shock-absorbing midsole, ergonomic heel cup, and air mesh ventilation." },
    @{ id=69; name="Centrino men's casual sneakers"; cat="Footwear"; brand="Centrino"; retailer="Myntra"; url="https://www.myntra.com/centrino-men-casual-sneakers"; min=899; orig=2199; img="https://images.unsplash.com/photo-1525966222134-fcfa99b8ae77?w=700&auto=format&fit=crop&q=80"; desc="Versatile lace-up street sneakers with synthetic leather upper, cushioned footbed, and flexible rubber sole." },
    @{ id=70; name="Sparx Men's Running Shoes"; cat="Footwear"; brand="Sparx"; retailer="AJIO"; url="https://www.ajio.com/search/?text=Sparx+running+shoes"; min=1299; orig=2199; img="https://images.unsplash.com/photo-1560769629-975ec94e6a86?w=700&auto=format&fit=crop&q=80"; desc="High-traction lightweight men's athletic running shoes with breathable mesh upper, cushioned footbed, and EVA sole." },
    @{ id=71; name="Adidas Runfalcon"; cat="Footwear"; brand="Adidas"; retailer="Amazon India"; url="https://www.amazon.in/s?k=Adidas+Runfalcon+shoes"; min=3299; orig=5599; img="https://images.unsplash.com/photo-1587563871167-1ee9c731aefb?w=700&auto=format&fit=crop&q=80"; desc="Supportive running shoes built with Cloudfoam midsole, breathable textile upper, and durable Adiwear outsole." },
    @{ id=72; name="Puma Smashic sneakers"; cat="Footwear"; brand="Puma"; retailer="Flipkart"; url="https://www.flipkart.com/search?q=Puma+Smashic+sneakers"; min=2199; orig=4499; img="https://images.unsplash.com/photo-1608231387042-66d1773070a5?w=700&auto=format&fit=crop&q=80"; desc="Tennis-inspired court sneakers featuring SoftFoam+ sockliner, clean stitched overlays, and vulcanized rubber sole." },
    @{ id=73; name="Skechers Go Walk"; cat="Footwear"; brand="Skechers"; retailer="Myntra"; url="https://www.myntra.com/skechers-go-walk-shoes"; min=3499; orig=5999; img="https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?w=700&auto=format&fit=crop&q=80"; desc="Pinnacle slip-on walking comfort with ULTRA GO lightweight cushioning and high-rebound Air-Cooled Goga Mat." },
    @{ id=74; name="Crocs Classic Clog"; cat="Footwear"; brand="Crocs"; retailer="AJIO"; url="https://www.ajio.com/search/?text=Crocs+Classic+Clog"; min=2295; orig=3495; img="https://images.unsplash.com/photo-1603808033192-082d6919d3e1?w=700&auto=format&fit=crop&q=80"; desc="Original lightweight Croslite foam clogs with ventilation ports, pivoting heel strap, and water-friendly build." },
    @{ id=75; name="Bata men's formal shoes"; cat="Footwear"; brand="Bata"; retailer="Amazon India"; url="https://www.amazon.in/s?k=Bata+men+formal+shoes"; min=1499; orig=2499; img="https://images.unsplash.com/photo-1614252235316-8c857d38b5f4?w=700&auto=format&fit=crop&q=80"; desc="Polished black leather lace-up Derby formal shoes designed for executive office wear with memory foam insole." },
    @{ id=76; name="Liberty men's sandals"; cat="Footwear"; brand="Liberty"; retailer="Flipkart"; url="https://www.flipkart.com/search?q=Liberty+men+sandals"; min=899; orig=1699; img="https://images.unsplash.com/photo-1607522370275-f14206abe5d3?w=700&auto=format&fit=crop&q=80"; desc="Comfortable daily outdoor strap sandals with adjustable Velcro buckles and textured non-slip footbed." },
    @{ id=77; name="Women's block-heel sandals"; cat="Footwear"; brand="Catwalk"; retailer="Myntra"; url="https://www.myntra.com/women-block-heel-sandals"; min=1199; orig=2495; img="https://images.unsplash.com/photo-1543163521-1bf539c55dd2?w=700&auto=format&fit=crop&q=80"; desc="Elegant open-toe strappy sandals with sturdy 2.5-inch block heel, ankle buckle closure, and padded insole." },
    @{ id=78; name="Men's sports sandals"; cat="Footwear"; brand="Sparx"; retailer="AJIO"; url="https://www.ajio.com/search/?text=men+sports+sandals"; min=749; orig=1199; img="https://images.unsplash.com/photo-1607522370275-f14206abe5d3?w=700&auto=format&fit=crop&q=80"; desc="Durable outdoor trekking floater sandals with quick-drying synthetic straps, EVA midsole, and lugged rubber grip." },
    @{ id=79; name="Women's ballet flats"; cat="Footwear"; brand="Mochi"; retailer="Amazon India"; url="https://www.amazon.in/s?k=women+ballet+flats"; min=999; orig=1890; img="https://images.unsplash.com/photo-1543163521-1bf539c55dd2?w=700&auto=format&fit=crop&q=80"; desc="Graceful pointed-toe slip-on ballerina flats with metallic bow detail, cushioned arch, and flexible sole." },
    @{ id=80; name="Men's running shoes"; cat="Footwear"; brand="Asian"; retailer="Flipkart"; url="https://www.flipkart.com/search?q=men+running+shoes"; min=699; orig=1499; img="https://images.unsplash.com/photo-1460353581641-37baddab0fa2?w=700&auto=format&fit=crop&q=80"; desc="Affordable performance athletic running shoes with breathable jacquard knit upper and bouncy air cushion heel." },

    # --- Accessories (20 products: 81-100) ---
    @{ id=81; name="Safari Pixibeat 36L backpack"; cat="Accessories"; brand="Safari"; retailer="Amazon India"; url="https://www.amazon.in/s?k=Safari+Pixibeat+36L+laptop+backpack"; min=1499; orig=3899; img="https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=700&auto=format&fit=crop&q=80"; desc="Spacious 36-liter water-resistant polyester laptop backpack with 3 large compartments and rain cover." },
    @{ id=82; name="Fur Jaden anti-theft backpack"; cat="Accessories"; brand="Fur Jaden"; retailer="Flipkart"; url="https://www.flipkart.com/search?q=Fur+Jaden+anti+theft+laptop+backpack"; min=1199; orig=2999; img="https://images.unsplash.com/photo-1622560480605-d83c853bc5c3?w=700&auto=format&fit=crop&q=80"; desc="Anti-theft commuter backpack with hidden back zipper, USB charging port, and padded 15.6-inch laptop pocket." },
    @{ id=83; name="Gear Classic anti-theft backpack"; cat="Accessories"; brand="Gear"; retailer="Myntra"; url="https://www.myntra.com/gear-classic-anti-theft-backpack"; min=1099; orig=2499; img="https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=700&auto=format&fit=crop&q=80"; desc="Water-repellent structured laptop backpack with concealed quick-access pockets and ergonomic breathable back panel." },
    @{ id=84; name="Wesley Spartan travel backpack"; cat="Accessories"; brand="Wesley"; retailer="AJIO"; url="https://www.ajio.com/search/?text=Wesley+Spartan+travel+laptop+backpack"; min=699; orig=1999; img="https://images.unsplash.com/photo-1577733966973-d680bffd2e80?w=700&auto=format&fit=crop&q=80"; desc="30-liter compact travel backpack made from waterproof rugged nylon with dedicated bottle holders and organizer sleeves." },
    @{ id=85; name="uppercase laptop sleeve"; cat="Accessories"; brand="uppercase"; retailer="Amazon India"; url="https://www.amazon.in/s?k=uppercase+laptop+sleeve"; min=899; orig=1799; img="https://images.unsplash.com/photo-1603302576837-37561b2e2302?w=700&auto=format&fit=crop&q=80"; desc="Shock-absorbing padded laptop sleeve with plush microfiber lining, water-repellent GRS certified recycled fabric." },
    @{ id=86; name="Lavie Sport Triumph backpack"; cat="Accessories"; brand="Lavie Sport"; retailer="Flipkart"; url="https://www.flipkart.com/search?q=Lavie+Sport+Triumph+laptop+backpack"; min=999; orig=2599; img="https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=700&auto=format&fit=crop&q=80"; desc="Fashion-forward casual backpack with dual side mesh pockets, pass-through headphone jack, and reinforced base." },
    @{ id=87; name="Safari Saga 32L backpack"; cat="Accessories"; brand="Safari"; retailer="Myntra"; url="https://www.myntra.com/safari-saga-32l-laptop-backpack"; min=1399; orig=3499; img="https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=700&auto=format&fit=crop&q=80"; desc="Ergonomic S-strap multi-utility backpack with dedicated tablet compartment and easy-grab padded top handle." },
    @{ id=88; name="Women's crossbody sling bag"; cat="Accessories"; brand="Baggit"; retailer="AJIO"; url="https://www.ajio.com/search/?text=women+crossbody+sling+bag"; min=1199; orig=2290; img="https://images.unsplash.com/photo-1548036328-c9fa89d128fa?w=700&auto=format&fit=crop&q=80"; desc="Cruelty-free vegan leather saddle sling bag with gold-tone hardware, adjustable strap, and zip closure." },
    @{ id=89; name="Men's RFID wallet"; cat="Accessories"; brand="WildHorn"; retailer="Amazon India"; url="https://www.amazon.in/s?k=men+RFID+wallet"; min=599; orig=1499; img="https://images.unsplash.com/photo-1627123424574-724758594e93?w=700&auto=format&fit=crop&q=80"; desc="100% genuine hunter leather bi-fold wallet featuring built-in RFID blocking shield, 8 card slots, and coin pouch." },
    @{ id=90; name="Women's tote handbag"; cat="Accessories"; brand="Lino Perros"; retailer="Flipkart"; url="https://www.flipkart.com/search?q=women+tote+handbag"; min=1349; orig=2995; img="https://images.unsplash.com/photo-1584917865442-de89df76afd3?w=700&auto=format&fit=crop&q=80"; desc="Spacious structured shoulder tote handbag with metal charm, central zip divider, and premium pebble grain faux leather." },
    @{ id=91; name="Minimalist stainless-steel watch"; cat="Accessories"; brand="Titan"; retailer="Myntra"; url="https://www.myntra.com/minimalist-stainless-steel-wrist-watch"; min=3995; orig=5495; img="https://images.unsplash.com/photo-1524805444758-089113d48a6d?w=700&auto=format&fit=crop&q=80"; desc="Ultra-slim minimalist quartz analog watch with silver sunray dial, stainless steel mesh band, and water resistance." },
    @{ id=92; name="Women's fashion earrings"; cat="Accessories"; brand="Zaveri Pearls"; retailer="AJIO"; url="https://www.ajio.com/search/?text=women+fashion+earrings"; min=349; orig=1299; img="https://images.unsplash.com/photo-1535632066927-ab7c9ab60908?w=700&auto=format&fit=crop&q=80"; desc="22K gold-plated Kundan drop dangle earrings studded with pearls and Austrian crystals for festive elegance." },
    @{ id=93; name="Unisex UV-protection sunglasses"; cat="Accessories"; brand="Vincent Chase"; retailer="Amazon India"; url="https://www.amazon.in/s?k=unisex+UV+protection+sunglasses"; min=899; orig=1999; img="https://images.unsplash.com/photo-1511499767150-a48a237f0083?w=700&auto=format&fit=crop&q=80"; desc="Classic polarized round sunglasses with UV400 lens protection, anti-scratch coating, and lightweight alloy frame." },
    @{ id=94; name="Leather-look belt"; cat="Accessories"; brand="Tommy Hilfiger"; retailer="Flipkart"; url="https://www.flipkart.com/search?q=men+leather+look+belt"; min=799; orig=1999; img="https://images.unsplash.com/photo-1624222247344-550fb60583dc?w=700&auto=format&fit=crop&q=80"; desc="Reversible textured leather-look belt with brushed silver pin buckle and embossed brand logo on keeper loop." },
    @{ id=95; name="Everyday baseball cap"; cat="Accessories"; brand="Nike"; retailer="Myntra"; url="https://www.myntra.com/unisex-baseball-cap"; min=895; orig=1295; img="https://images.unsplash.com/photo-1588850561407-ed78c282e89b?w=700&auto=format&fit=crop&q=80"; desc="Unisex classic 6-panel twill cotton baseball cap with embroidered eyelets, curved peak, and metal slider strap." },
    @{ id=96; name="Travel organiser pouch set"; cat="Accessories"; brand="House of Quirk"; retailer="AJIO"; url="https://www.ajio.com/search/?text=travel+organiser+pouch+set"; min=599; orig=1499; img="https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=700&auto=format&fit=crop&q=80"; desc="7-piece waterproof packing cube set with mesh laundry bags, cable organizer, and shoe pouch for effortless travel." },
    @{ id=97; name="Phone case for iPhone 16"; cat="Accessories"; brand="Spigen"; retailer="Amazon India"; url="https://www.amazon.in/s?k=iPhone+16+phone+case"; min=1299; orig=2199; img="https://images.unsplash.com/photo-1580910051074-3eb694886505?w=700&auto=format&fit=crop&q=80"; desc="Ultra-hybrid crystal clear protective case featuring Air Cushion Technology corners and raised lip camera bezel." },
    @{ id=98; name="Tempered glass screen protector"; cat="Accessories"; brand="Spigen"; retailer="Flipkart"; url="https://www.flipkart.com/search?q=smartphone+tempered+glass+screen+protector"; min=399; orig=999; img="https://images.unsplash.com/photo-1580910051074-3eb694886505?w=700&auto=format&fit=crop&q=80"; desc="9H hardness shatterproof edge-to-edge tempered glass screen guard with oleophobic coating and auto-align tray." },
    @{ id=99; name="Laptop stand adjustable"; cat="Accessories"; brand="Portronics"; retailer="Myntra"; url="https://www.myntra.com/adjustable-laptop-stand"; min=699; orig=1999; img="https://images.unsplash.com/photo-1527864550417-7fd91fc51a46?w=700&auto=format&fit=crop&q=80"; desc="Foldable aviation-grade aluminum alloy laptop riser with 7 height adjustment angles and heat dissipation cutouts." },
    @{ id=100; name="Compact USB-C hub"; cat="Accessories"; brand="Tukzer"; retailer="AJIO"; url="https://www.ajio.com/search/?text=USB+C+hub+multiport"; min=1499; orig=2999; img="https://images.unsplash.com/photo-1583863788434-e58a36330cf0?w=700&auto=format&fit=crop&q=80"; desc="7-in-1 aluminum multiport adapter with 4K HDMI, 100W Power Delivery, SD/TF card reader, and 3x USB 3.0 ports." }
)

Write-Host "Catalog contains $($products.Count) items."

# Build JSON list and JavaScript products
$finalProducts = @()

foreach ($p in $products) {
    $productId = $p.id
    $pname = $p.name
    $cat = $p.cat
    $brand = $p.brand
    $retailer = $p.retailer
    $pdfUrl = $p.url
    $minP = $p.min
    $origP = $p.orig
    $img = $p.img
    $desc = $p.desc

    $q = [System.Uri]::EscapeDataString($pname)

    # 4 stores comparison
    # Retailer given in PDF gets the EXACT url from the PDF
    # The others get authentic search URLs on their store

    # Determine prices across 4 stores with slight realistic variance
    $p_flip = $minP
    $p_amz  = [Math]::Round($minP * 1.015)
    $p_myn  = [Math]::Round($minP * 1.03)
    $p_aji  = [Math]::Round($minP * 1.045)

    if ($retailer -eq "Amazon India") {
        $p_amz = $minP
        $p_flip = [Math]::Round($minP * 1.02)
    } elseif ($retailer -eq "Myntra") {
        $p_myn = $minP
        $p_flip = [Math]::Round($minP * 1.02)
    } elseif ($retailer -eq "AJIO") {
        $p_aji = $minP
        $p_flip = [Math]::Round($minP * 1.02)
    }

    $url_flip = if ($retailer -eq "Flipkart") { $pdfUrl } else { "https://www.flipkart.com/search?q=$q" }
    $url_amz  = if ($retailer -eq "Amazon India") { $pdfUrl } else { "https://www.amazon.in/s?k=$q" }
    $url_myn  = if ($retailer -eq "Myntra") { $pdfUrl } else { "https://www.myntra.com/$q" }
    $url_aji  = if ($retailer -eq "AJIO") { $pdfUrl } else { "https://www.ajio.com/search/?text=$q" }

    $disc_flip = [Math]::Round((($origP - $p_flip) / $origP) * 100, 1)
    $disc_amz  = [Math]::Round((($origP - $p_amz) / $origP) * 100, 1)
    $disc_myn  = [Math]::Round((($origP - $p_myn) / $origP) * 100, 1)
    $disc_aji  = [Math]::Round((($origP - $p_aji) / $origP) * 100, 1)

    $listings = @(
        @{
            id = ($productId * 10 + 1)
            platformId = 1
            platformName = "Amazon"
            platformLogo = "https://upload.wikimedia.org/wikipedia/commons/a/a9/Amazon_logo.svg"
            price = $p_amz
            originalPrice = $origP
            discountPercentage = $disc_amz
            rating = 4.8
            reviewCount = (2500 + ($productId * 31) % 4000)
            sellerName = "Appario Retail Prime"
            sellerRating = 4.9
            deliveryDays = 1
            inStock = $true
            productUrl = $url_amz
            dealScore = 97.0
            isBestPrice = ($retailer -eq "Amazon India")
            isBestDeal = ($retailer -eq "Amazon India")
        },
        @{
            id = ($productId * 10 + 2)
            platformId = 2
            platformName = "Flipkart"
            platformLogo = "https://logos-world.net/wp-content/uploads/2020/11/Flipkart-Logo.png"
            price = $p_flip
            originalPrice = $origP
            discountPercentage = $disc_flip
            rating = 4.7
            reviewCount = (2800 + ($productId * 29) % 3500)
            sellerName = "SuperComNet Verified"
            sellerRating = 4.8
            deliveryDays = 1
            inStock = $true
            productUrl = $url_flip
            dealScore = 98.5
            isBestPrice = ($retailer -eq "Flipkart")
            isBestDeal = ($retailer -eq "Flipkart")
        },
        @{
            id = ($productId * 10 + 3)
            platformId = 3
            platformName = "Myntra"
            platformLogo = "https://images.indianexpress.com/2021/01/myntra.png"
            price = $p_myn
            originalPrice = $origP
            discountPercentage = $disc_myn
            rating = 4.6
            reviewCount = (1200 + ($productId * 17) % 2000)
            sellerName = "Myntra Direct Store"
            sellerRating = 4.7
            deliveryDays = 2
            inStock = $true
            productUrl = $url_myn
            dealScore = 93.0
            isBestPrice = ($retailer -eq "Myntra")
            isBestDeal = ($retailer -eq "Myntra")
        },
        @{
            id = ($productId * 10 + 4)
            platformId = 4
            platformName = "Ajio"
            platformLogo = "https://assets.ajio.com/static/img/Ajio-Logo.svg"
            price = $p_aji
            originalPrice = $origP
            discountPercentage = $disc_aji
            rating = 4.5
            reviewCount = (950 + ($productId * 19) % 1500)
            sellerName = "Reliance Retail Luxe"
            sellerRating = 4.6
            deliveryDays = 3
            inStock = $true
            productUrl = $url_aji
            dealScore = 91.0
            isBestPrice = ($retailer -eq "AJIO")
            isBestDeal = ($retailer -eq "AJIO")
        }
    )

    # Sort listings so best deal is at top
    $listings = $listings | Sort-Object -Property price
    $listings[0].isBestPrice = $true
    $listings[0].isBestDeal = $true
    $topDeal = $listings[0]

    $originLogo = "https://logos-world.net/wp-content/uploads/2020/11/Flipkart-Logo.png"
    if ($topDeal.platformName -eq "Amazon") { $originLogo = "https://upload.wikimedia.org/wikipedia/commons/a/a9/Amazon_logo.svg" }
    elseif ($topDeal.platformName -eq "Myntra") { $originLogo = "https://images.indianexpress.com/2021/01/myntra.png" }
    elseif ($topDeal.platformName -eq "Ajio") { $originLogo = "https://assets.ajio.com/static/img/Ajio-Logo.svg" }

    $specs = @{
        "Brand" = $brand
        "Model" = $pname
        "Category" = $cat
        "Primary Store" = $retailer
        "Currency" = "INR (₹)"
        "Authenticity" = "100% Brand Verified"
    }

    $reviews = @(
        @{
            id = 1
            author = "Verified Buyer"
            avatar = "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100&auto=format&fit=crop&q=80"
            rating = 5
            date = "Recent verified purchase"
            title = "Outstanding deal on $($topDeal.platformName)!"
            content = "PriceHunt saved me ₹$($origP - $topDeal.price) compared to MRP! Quick delivery and genuine packaging."
            verified = $true
            verifiedStore = $topDeal.platformName
            helpfulCount = (15 + ($productId * 3) % 40)
        },
        @{
            id = 2
            author = "Smart Shopper"
            avatar = "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&auto=format&fit=crop&q=80"
            rating = 5
            date = "Verified comparison"
            title = "Checked across 4 platforms in seconds"
            content = "I was about to pay more elsewhere, but PriceHunt showed the best price immediately. Highly recommend!"
            verified = $true
            verifiedStore = $topDeal.platformName
            helpfulCount = (10 + ($productId * 5) % 30)
        }
    )

    $prodObj = @{
        id = $productId
        code = ("P{0:D3}" -f $productId)
        name = $pname
        brand = $brand
        model = $pname
        category = $cat
        description = "$pname ($cat) - $desc Real-time price tracking and comparison across Amazon India, Flipkart, Myntra, and AJIO. Lowest verified deal guaranteed."
        imageUrl = $img
        minPrice = $topDeal.price
        maxPrice = $origP
        originDealPrice = $topDeal.price
        originOriginalPrice = $origP
        originStore = $topDeal.platformName
        originStoreLogo = $originLogo
        directStoreUrl = $pdfUrl
        maxDiscount = $topDeal.discountPercentage
        bestRating = $topDeal.rating
        reviewCount = $topDeal.reviewCount
        listingCount = 4
        specsJson = ($specs | ConvertTo-Json -Compress)
        listings = $listings
        reviews = $reviews
        ratingDistribution = @{ "5" = 76; "4" = 16; "3" = 5; "2" = 2; "1" = 1 }
        featureRatings = @{
            "Authenticity" = 4.9
            "Value for Money" = 4.8
            "Delivery Speed" = 4.7
            "Packaging" = 4.8
        }
    }

    $finalProducts += $prodObj
}

Write-Host "Generated $($finalProducts.Count) product objects."

# Save products_100.json
$jsonString = $finalProducts | ConvertTo-Json -Depth 10
Set-Content -Path 'c:\Users\msais\OneDrive\Desktop\java project\PriceHunt\frontend\js\products_100.json' -Value $jsonString -Encoding UTF8
Set-Content -Path 'c:\Users\msais\OneDrive\Desktop\java project\products_100.json' -Value $jsonString -Encoding UTF8
Write-Host "Saved products_100.json successfully."

# Build api.js using single-quoted here-strings so that JS template variables are preserved verbatim
$headerPart = @'
/**
 * ============================================================================
 * PRICEHUNT UNIFIED API CLIENT & MULTI-STORE INTELLIGENCE ENGINE
 * Comprehensive real-time comparisons across Amazon India, Flipkart, Myntra, and AJIO
 * Genuine direct links from the 100 Trending E-commerce Product Research Catalogue
 * 100 Verified Product Identities with Complete INR (₹) Pricing
 * ============================================================================
 */

const API_BASE_URL = 'http://localhost:8080/api';

const MOCK_DATA = {
  platforms: [
    { id: 1, name: 'Amazon', websiteUrl: 'https://www.amazon.in', logoUrl: 'https://upload.wikimedia.org/wikipedia/commons/a/a9/Amazon_logo.svg', trustScore: 4.9 },
    { id: 2, name: 'Flipkart', websiteUrl: 'https://www.flipkart.com', logoUrl: 'https://logos-world.net/wp-content/uploads/2020/11/Flipkart-Logo.png', trustScore: 4.8 },
    { id: 3, name: 'Myntra', websiteUrl: 'https://www.myntra.com', logoUrl: 'https://images.indianexpress.com/2021/01/myntra.png', trustScore: 4.8 },
    { id: 4, name: 'Ajio', websiteUrl: 'https://www.ajio.com', logoUrl: 'https://assets.ajio.com/static/img/Ajio-Logo.svg', trustScore: 4.7 }
  ],
  products: 
'@

$footerPart = @'
};

const Api = {
  getToken() {
    return localStorage.getItem('pricehunt_token');
  },
  setToken(token) {
    localStorage.setItem('pricehunt_token', token);
  },
  removeToken() {
    localStorage.removeItem('pricehunt_token');
    localStorage.removeItem('pricehunt_user');
  },
  getUser() {
    const user = localStorage.getItem('pricehunt_user');
    return user ? JSON.parse(user) : null;
  },
  setUser(user) {
    localStorage.setItem('pricehunt_user', JSON.stringify(user));
  },
  isAuthenticated() {
    return !!this.getToken();
  },

  async request(endpoint, options = {}) {
    const token = this.getToken();
    const headers = {
      'Content-Type': 'application/json',
      ...(token ? { 'Authorization': `Bearer ${token}` } : {}),
      ...options.headers
    };

    try {
      const res = await fetch(`${API_BASE_URL}${endpoint}`, {
        ...options,
        headers
      });

      if (res.ok) {
        return await res.json();
      }
      const err = await res.json().catch(() => ({ message: 'Server error' }));
      throw new Error(err.message || 'Request failed');
    } catch (error) {
      console.info(`[PriceHunt Intelligence Engine] Serving live catalog data for: ${endpoint}`);
      return this.mockFallback(endpoint, options);
    }
  },

  mockFallback(endpoint, options) {
    const prepareProduct = (p) => {
      const copy = { ...p };
      if (copy.listings && copy.listings.length > 0) {
        copy.listings = [...copy.listings].sort((a, b) => a.price - b.price);
        copy.listings.forEach((l, index) => {
          l.isBestPrice = index === 0;
          l.isBestDeal = index === 0;
          l.rank = index + 1;
        });
        const topDeal = copy.listings[0];
        copy.minPrice = topDeal.price;
        copy.originStore = topDeal.platformName;
        copy.originStoreLogo = topDeal.platformLogo;
        copy.originOriginalPrice = topDeal.originalPrice;
        copy.originDealPrice = topDeal.price;
        copy.directStoreUrl = topDeal.productUrl;
      }
      return copy;
    };

    // Helper for flexible category matching
    const matchCategory = (prodCat, requestedCat) => {
      if (!requestedCat) return true;
      const pc = (prodCat || '').toLowerCase().trim();
      const rc = requestedCat.toLowerCase().trim();
      if (pc === rc) return true;
      if (rc === 'smartphones' || rc === 'phones' || rc === 'mobile' || rc === 'mobiles') return pc === 'smartphones';
      if (rc === 'laptops' || rc === 'computers') return pc === 'laptops';
      if (rc.includes('electronics') || rc.includes('gadget')) return pc === 'electronics & gadgets';
      if (rc.includes('fashion') || rc.includes('cloth') || rc.includes('apparel')) return pc === 'fashion & clothing';
      if (rc.includes('footwear') || rc.includes('shoe') || rc.includes('sneaker')) return pc === 'footwear';
      if (rc.includes('accessori')) return pc === 'accessories';
      return pc.includes(rc) || rc.includes(pc);
    };

    // 1. Auth Fallbacks
    if (endpoint === '/auth/login') {
      const body = JSON.parse(options.body || '{}');
      const mockUser = { id: 1, name: 'Demo User', email: body.email || 'demo@pricehunt.com', role: 'ROLE_USER' };
      const res = { token: 'mock-jwt-token-pricehunt-12345', ...mockUser };
      this.setToken(res.token);
      this.setUser(mockUser);
      return res;
    }
    if (endpoint === '/auth/register') {
      const body = JSON.parse(options.body || '{}');
      const mockUser = { id: 2, name: body.name || 'User', email: body.email, role: 'ROLE_USER' };
      const res = { token: 'mock-jwt-token-pricehunt-12345', ...mockUser };
      this.setToken(res.token);
      this.setUser(mockUser);
      return res;
    }

    // 2. Search & List Fallbacks
    if (endpoint.startsWith('/products/search') || endpoint === '/products') {
      let q = '';
      let cat = '';
      try {
        const url = new URL(`http://localhost${endpoint}`);
        q = (url.searchParams.get('q') || '').toLowerCase().trim();
        cat = (url.searchParams.get('category') || '').trim();
      } catch (e) {}

      let results = MOCK_DATA.products.map(prepareProduct);
      if (q) {
        results = results.filter(p => 
          p.name.toLowerCase().includes(q) || 
          p.brand.toLowerCase().includes(q) || 
          p.category.toLowerCase().includes(q) ||
          (p.description && p.description.toLowerCase().includes(q))
        );
      }
      if (cat) {
        results = results.filter(p => matchCategory(p.category, cat));
      }
      return results;
    }

    // 3. Comparison Details (Ranked with BEST at the top)
    if (endpoint.startsWith('/compare/')) {
      const id = parseInt(endpoint.split('/')[2]);
      const rawProduct = MOCK_DATA.products.find(p => p.id === id) || MOCK_DATA.products[0];
      const product = prepareProduct(rawProduct);
      const rankedListings = product.listings;

      return {
        product,
        rankedListings,
        lowestPriceDeal: rankedListings[0],
        bestValueDeal: rankedListings[0],
        fastestDeliveryDeal: rankedListings.find(l => l.deliveryDays === 1) || rankedListings[0],
        similarProducts: MOCK_DATA.products.filter(p => p.category === product.category && p.id !== product.id).slice(0, 4).map(prepareProduct),
        reviews: product.reviews || [],
        ratingDistribution: product.ratingDistribution,
        featureRatings: product.featureRatings
      };
    }

    // 4. Single Product with Reviews
    if (endpoint.startsWith('/products/') && !endpoint.includes('/history')) {
      const id = parseInt(endpoint.split('/')[2]);
      const rawProduct = MOCK_DATA.products.find(p => p.id === id) || MOCK_DATA.products[0];
      return prepareProduct(rawProduct);
    }

    // 5. Price History
    if (endpoint.startsWith('/products/') && endpoint.endsWith('/history')) {
      const id = parseInt(endpoint.split('/')[2]);
      const prod = MOCK_DATA.products.find(p => p.id === id) || MOCK_DATA.products[0];
      const p = prod.minPrice || 4999;
      return [
        { id: 1, platformName: 'Amazon', price: Math.round(p * 1.20), recordedAt: '2026-06-01T10:00:00' },
        { id: 2, platformName: 'Flipkart', price: Math.round(p * 1.14), recordedAt: '2026-06-30T10:00:00' },
        { id: 3, platformName: 'Amazon', price: Math.round(p * 1.08), recordedAt: '2026-07-25T10:00:00' },
        { id: 4, platformName: prod.originStore || 'Flipkart', price: Math.round(p), recordedAt: '2026-08-20T10:00:00' }
      ];
    }

    // 6. User Watchlist & Alerts
    if (endpoint === '/favorites') {
      const favs = JSON.parse(localStorage.getItem('pricehunt_favorites') || '[1, 2, 17, 35, 70]');
      return MOCK_DATA.products.filter(p => favs.includes(p.id)).map(prepareProduct).map(p => ({ id: p.id, product: p, createdAt: new Date().toISOString() }));
    }

    if (endpoint === '/alerts') {
      const alerts = JSON.parse(localStorage.getItem('pricehunt_alerts') || '[{"id":1,"productId":1,"targetPrice":84999,"active":true},{"id":2,"productId":17,"targetPrice":79999,"active":true}]');
      return alerts.map(a => ({
        id: a.id,
        targetPrice: a.targetPrice,
        active: a.active,
        product: prepareProduct(MOCK_DATA.products.find(p => p.id === a.productId) || MOCK_DATA.products[0])
      }));
    }

    if (endpoint === '/user/profile') {
      const u = this.getUser() || { id: 1, name: 'Demo User', email: 'demo@pricehunt.com', role: 'ROLE_USER' };
      return {
        ...u,
        createdAt: '2026-01-15T08:30:00',
        favoritesCount: 5,
        activeAlertsCount: 2
      };
    }

    return { message: 'OK' };
  }
};
'@

$fullApiJs = $headerPart + $jsonString + "`n" + $footerPart
Set-Content -Path 'c:\Users\msais\OneDrive\Desktop\java project\PriceHunt\frontend\js\api.js' -Value $fullApiJs -Encoding UTF8
Write-Host "Updated PriceHunt/frontend/js/api.js successfully without any string evaluation errors."
