# Read api.js content
$jsContent = [System.IO.File]::ReadAllText("$PSScriptRoot\..\frontend\js\api.js")

# Find products: [ and the matching closing bracket
$marker = "products: ["
$startPos = $jsContent.IndexOf($marker)
if ($startPos -lt 0) {
    Write-Error "Could not find 'products: [' in api.js"
    exit 1
}

$startPos += "products:".Length
$openBrackets = 0
$endPos = -1
$inString = $false
$escape = $false

for ($i = $startPos; $i -lt $jsContent.Length; $i++) {
    $c = $jsContent[$i]
    if ($escape) {
        $escape = $false
        continue
    }
    if ($c -eq '\') {
        $escape = $true
        continue
    }
    if ($c -eq '"' -or $c -eq "'") {
        # Note: in this json, all keys/strings are double-quoted
    }
    if ($c -eq '[') {
        $openBrackets++
    } elseif ($c -eq ']') {
        $openBrackets--
        if ($openBrackets -eq 0) {
            $endPos = $i
            break
        }
    }
}

if ($endPos -lt 0) {
    Write-Error "Could not find matching closing bracket for products array"
    exit 1
}

$jsonText = $jsContent.Substring($startPos, $endPos - $startPos + 1).Trim()

# Verify JSON
$parsed = $jsonText | ConvertFrom-Json
Write-Host "Successfully parsed products count: $($parsed.Count)"

$outDir = "$PSScriptRoot\..\backend\src\main\resources\data"
if (-not (Test-Path $outDir)) {
    New-Item -ItemType Directory -Path $outDir -Force | Out-Null
}

$outFile = "$outDir\products-catalog.json"
[System.IO.File]::WriteAllText($outFile, $jsonText, [System.Text.Encoding]::UTF8)
Write-Host "Wrote products catalog JSON to: $outFile"

