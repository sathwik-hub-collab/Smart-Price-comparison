$testUrls = @(
    'https://www.amazon.in/s?k=Apple+iPhone+17+smartphone',
    'https://www.flipkart.com/search?q=Apple+iPhone+16+128GB',
    'https://www.myntra.com/men-oversized-graphic-t-shirt',
    'https://www.ajio.com/search/?text=USB+C+hub+multiport'
)

foreach ($url in $testUrls) {
    Write-Host "Testing URL: $url" -ForegroundColor Cyan
    $body = @{ url = $url } | ConvertTo-Json
    $resp = Invoke-RestMethod -Uri 'http://localhost:8080/api/compare/url' -Method Post -ContentType 'application/json' -Body $body
    Write-Host "Matched Product: $($resp.product.name)" -ForegroundColor Green
    Write-Host "Lowest Price: ₹$($resp.lowestPrice) | Highest Price: ₹$($resp.highestPrice) | Savings: ₹$($resp.maxPotentialSavings)"
    Write-Host "Total Offers: $($resp.offers.Count) -- 30-Day History Points: $($resp.priceHistory30Days.Count)"
    Write-Host "------------------------------------------------------------"
}

