# Generate 100 products JSON for PriceHunt
$jsonPath = 'c:\Users\msais\OneDrive\Desktop\java project\products_100.json'
$products = Get-Content $jsonPath -Raw | ConvertFrom-Json
$sqlGen = Get-Content 'c:\Users\msais\OneDrive\Desktop\java project\generate_sql_seed.ps1' -Raw
$priceMap = Invoke-Expression (($sqlGen -split '\$priceMap =')[-1] -split '# 1\. Generate MySQL')[0]

$jsProducts = @()
$idCount = 1

foreach ($p in $products) {
    $productId = $idCount
    $pcode = $p.product_id
    $pinfo = $priceMap[$pcode]
    $minP = $pinfo.min
    $origP = $pinfo.orig
    $img = $pinfo.img

    $varSuffix = ""
    if ($p.variant) { $varSuffix = " (" + $p.variant + ")" }
    $fullName = ($p.brand + " " + $p.product_name + $varSuffix).Trim()
    $brand = $p.brand
    $model = $p.product_name
    $cat = $p.category

    $specs = @{
        "Brand" = $brand;
        "Model" = $model;
        "Variant" = $p.variant;
        "Category" = $cat;
        "Type" = $p.product_type;
        "Currency" = "INR (₹)"
    }
    $specsJsonStr = $specs | ConvertTo-Json -Compress

    $q = [System.Uri]::EscapeDataString("$brand $model $($p.variant)".Trim())
    $qShort = [System.Uri]::EscapeDataString("$brand $model".Trim())

    # 4 stores:
    # Flipkart (lowest / best price)
    $p_flip = $minP
    $url_flip = "https://www.flipkart.com/search?q=$q"
    $disc_flip = [Math]::Round((($origP - $p_flip) / $origP) * 100, 1)

    # Amazon
    $p_amz = [Math]::Round($minP * 1.01)
    $url_amz = "https://www.amazon.in/s?k=$q"
    $disc_amz = [Math]::Round((($origP - $p_amz) / $origP) * 100, 1)

    # Myntra
    $p_myn = [Math]::Round($minP * 1.03)
    $url_myn = "https://www.myntra.com/$qShort"
    $disc_myn = [Math]::Round((($origP - $p_myn) / $origP) * 100, 1)

    # AJIO
    $p_aji = [Math]::Round($minP * 1.05)
    $url_aji = "https://www.ajio.com/search/?text=$qShort"
    $disc_aji = [Math]::Round((($origP - $p_aji) / $origP) * 100, 1)

    $listings = @(
        @{
            id = ($productId * 10 + 1)
            platformId = 2
            platformName = "Flipkart"
            platformLogo = "https://logos-world.net/wp-content/uploads/2020/11/Flipkart-Logo.png"
            price = $p_flip
            originalPrice = $origP
            discountPercentage = $disc_flip
            rating = 4.8
            reviewCount = (4000 + ($productId * 37) % 3000)
            sellerName = "SuperComNet Verified"
            sellerRating = 4.8
            deliveryDays = 1
            inStock = $true
            productUrl = $url_flip
            dealScore = 99.0
            isBestPrice = $true
            isBestDeal = $true
        },
        @{
            id = ($productId * 10 + 2)
            platformId = 1
            platformName = "Amazon"
            platformLogo = "https://upload.wikimedia.org/wikipedia/commons/a/a9/Amazon_logo.svg"
            price = $p_amz
            originalPrice = $origP
            discountPercentage = $disc_amz
            rating = 4.7
            reviewCount = (4500 + ($productId * 41) % 4000)
            sellerName = "Appario Retail Prime"
            sellerRating = 4.9
            deliveryDays = 1
            inStock = $true
            productUrl = $url_amz
            dealScore = 96.5
            isBestPrice = $false
            isBestDeal = $false
        },
        @{
            id = ($productId * 10 + 3)
            platformId = 3
            platformName = "Myntra"
            platformLogo = "https://images.indianexpress.com/2021/01/myntra.png"
            price = $p_myn
            originalPrice = $origP
            discountPercentage = $disc_myn
            rating = 4.6
            reviewCount = (1500 + ($productId * 23) % 2000)
            sellerName = "Myntra Direct Store"
            sellerRating = 4.7
            deliveryDays = 2
            inStock = $true
            productUrl = $url_myn
            dealScore = 92.0
            isBestPrice = $false
            isBestDeal = $false
        },
        @{
            id = ($productId * 10 + 4)
            platformId = 4
            platformName = "Ajio"
            platformLogo = "https://assets.ajio.com/static/img/Ajio-Logo.svg"
            price = $p_aji
            originalPrice = $origP
            discountPercentage = $disc_aji
            rating = 4.5
            reviewCount = (1000 + ($productId * 19) % 1500)
            sellerName = "Reliance Retail Luxe"
            sellerRating = 4.6
            deliveryDays = 3
            inStock = $true
            productUrl = $url_aji
            dealScore = 89.0
            isBestPrice = $false
            isBestDeal = $false
        }
    )

    $savedInr = $origP - $minP
    $reviews = @(
        @{
            id = $productId
            author = "Verified Buyer"
            avatar = "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100&auto=format&fit=crop&q=80"
            rating = 5
            title = "Saved ₹" + $savedInr.ToString("N0") + " compared to MRP on Flipkart!"
            date = "Recent verified purchase"
            verifiedStore = "Flipkart"
            verified = $true
            content = "PriceHunt helped me compare prices in real-time across Amazon, Flipkart, Myntra, and Ajio. Found the lowest price on Flipkart with fast delivery!"
            helpfulCount = (30 + ($productId * 7) % 50)
        }
    )

    $prodObj = @{
        id = $productId
        code = $pcode
        name = $fullName
        brand = $brand
        model = $model
        category = $cat
        imageUrl = $img
        description = "$fullName - Real-time price tracking and comparison across Amazon India, Flipkart, Myntra, and AJIO. Lowest verified deal guaranteed."
        specsJson = $specsJsonStr
        minPrice = $minP
        maxPrice = $origP
        maxDiscount = $disc_flip
        bestRating = 4.8
        listingCount = 4
        originStore = "Flipkart"
        originStoreLogo = "https://logos-world.net/wp-content/uploads/2020/11/Flipkart-Logo.png"
        originOriginalPrice = $origP
        originDealPrice = $minP
        directStoreUrl = $url_flip
        listings = $listings
        ratingDistribution = @{ "5" = 75; "4" = 17; "3" = 5; "2" = 2; "1" = 1 }
        featureRatings = @{ "Value for Money" = 4.8; "Quality" = 4.9; "Authenticity" = 4.9 }
        reviews = $reviews
    }

    $jsProducts += $prodObj
    $idCount++
}

$productsJson = $jsProducts | ConvertTo-Json -Depth 6
$outJsonPath = 'c:\Users\msais\OneDrive\Desktop\java project\PriceHunt\frontend\js\products_100.json'
[System.IO.File]::WriteAllText($outJsonPath, $productsJson, [System.Text.Encoding]::UTF8)
Write-Host "Exported $($jsProducts.Count) products to $outJsonPath."
